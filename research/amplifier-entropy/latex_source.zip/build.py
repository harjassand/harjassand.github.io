#!/usr/bin/env python3
"""Build the paper with a local TeX installation; optionally render every page."""
from pathlib import Path
import argparse
import shutil
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--render", action="store_true",
                        help="render the PDF to page PNGs for visual inspection")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    for tool in ("pdflatex", "bibtex"):
        if shutil.which(tool) is None:
            raise SystemExit(f"Required program is not on PATH: {tool}")
    commands = [
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
         "-file-line-error", "main.tex"],
        ["bibtex", "main"],
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
         "-file-line-error", "main.tex"],
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
         "-file-line-error", "main.tex"],
    ]
    transcript = []
    for command in commands:
        result = subprocess.run(command, cwd=root, text=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        transcript.append("$ " + " ".join(command) + "\n" + result.stdout)
        if result.returncode:
            (root / "build-transcript.txt").write_text("\n".join(transcript))
            raise SystemExit(result.stdout)
    (root / "build-transcript.txt").write_text("\n".join(transcript))
    log = (root / "main.log").read_text()
    serious = [line for line in log.splitlines()
               if ("Overfull" in line or "undefined" in line
                   or "multiply defined" in line)]
    if serious:
        raise SystemExit("Build completed, but review the log:\n" + "\n".join(serious))
    if args.render:
        if shutil.which("pdftoppm") is None:
            raise SystemExit("PDF built; rendering needs pdftoppm on PATH.")
        pages = root / "rendered-pages"
        pages.mkdir(exist_ok=True)
        subprocess.run(["pdftoppm", "-r", "120", "-png",
                        str(root / "main.pdf"), str(pages / "page")],
                       check=True)
    print(root / "main.pdf")


if __name__ == "__main__":
    main()
