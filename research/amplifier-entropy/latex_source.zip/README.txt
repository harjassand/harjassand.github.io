Thermal balance and the amplifier entropy photon-number inequality
Editable source, 21 October 2026

Open main.tex as the main document. All section sources and the bibliography
are included. No external figures or private files are required.

Build with a current TeX Live or equivalent installation:
    python3 build.py
or:
    pdflatex main
    bibtex main
    pdflatex main
    pdflatex main

The source uses article, newpxtext/newpxmath, amsmath, amssymb, amsthm,
mathtools, microtype, natbib, titlesec, hyperref, bookmark, TikZ and flafter.
The monochrome proof diagram is drawn directly in LaTeX; no image file is needed.
The supplied main.bbl also permits compilation without running BibTeX.

Optional page rendering:
    python3 build.py --render
This needs pdftoppm (Poppler) for the visual layout check.

The acknowledgment immediately after the abstract records AI provenance.
No human mathematical authorship is assigned.

The adapted OpenAI material is credited in the paper and NOTICE.txt.
The inherited Apache License 2.0 is included as LICENSE.
