# Greatest Quantum Channels with Prescribed Maximal Information

Harjas Sandhu — 6 November 2026

## Build

Run from this directory:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The document uses standard TeX Live packages. Its figures are native TikZ; no
external images, bibliography database, network connection, or shell escape is
needed. `references.tex` contains the bibliography, with version-specific links
where theorem numbering is tied to a preprint.

The accompanying standalone `.tex` file contains the same manuscript and inline
bibliography. It can be compiled independently with `latexmk -pdf` or repeated
`pdflatex` runs.

## Contents

The main text develops complete RLD-profile classification, finite greatest
representatives, and exact/approximate greatest realizations for separable
trace-class outputs with a faithful tracial invariant. The later sections and
appendices give examples, finite symbolic witnesses, a full-support instability
family, finite probe identification, and conditioned stability. The infinite
nontracial problem, effective general filtrations, and the zero-capacity endpoint
problem are left open at their stated scopes.

The atomic/injective distinction, reverse-test and sufficiency theory,
amenability machinery, word-closure method, analytic identification principle,
and semialgebraic error-bound mechanism are credited to their primary sources.

## Supplementary exact arithmetic

With Python 3 and SymPy 1.14 installed:

```sh
python3 checks/check_examples.py
python3 checks/check_instability.py
```

The first script checks the worked matrix examples. The second checks the
rational positivity ingredients, complete symmetric-extension marginals, and
specified commutant determinant used in Appendix C, and writes
`checks/instability_checks.json`. These are supplementary finite identity checks;
the analytic proofs and infinite-dimensional arguments are in the manuscript.

The acknowledgement and AI-use statement appears near the end of the main text,
before the appendices.
