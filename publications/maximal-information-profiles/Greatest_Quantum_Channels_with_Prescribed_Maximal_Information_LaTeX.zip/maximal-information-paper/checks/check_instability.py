#!/usr/bin/env python3
"""Exact rational checks for full-support canonical-profile instability.

All Choi matrices are unnormalised and input-first.  Positivity is proved by
the displayed congruences/Schur bounds, not inferred from floating point.
"""
from pathlib import Path
import hashlib
import json
import sympy as s
from sympy.polys.matrices import DomainMatrix
from sympy.polys.domains import QQ_I

I = s.I
R = s.Rational
pauli = [s.eye(2), s.Matrix([[0, 1], [1, 0]]),
         s.Matrix([[0, -I], [I, 0]]), s.diag(1, -1)]
qv = [5, 1, 1, 1]
Q = s.diag(*qv)
omega = Q * Q / 14
lam = R(7, 8)
eta = R(1, 1024)


def e0(x):
    dx = lam*x + (1-lam)*s.trace(x)*s.eye(2)/2
    return s.Matrix(4, 4, lambda j, k:
                    R(qv[j]*qv[k], 28)*s.trace(pauli[j]*dx*pauli[k]))


D = s.diag(0, 1, 2, 3) - R(3, 14)*s.eye(4)
B = s.ones(4) - s.eye(4)


def endpoint(x):
    # x = (Tr x I + sum_i Tr(sigma_i x) sigma_i)/2.
    z = s.trace(x)*s.eye(4)
    z += (s.trace(pauli[1]*x)*B+s.trace(pauli[3]*x)*D)/16
    return s.simplify(Q*z*Q/28)


def choi(fun, din=2, dout=4):
    out = s.zeros(din*dout)
    for i in range(din):
        for j in range(din):
            u = s.zeros(din); u[i, j] = 1
            out[i*dout:(i+1)*dout, j*dout:(j+1)*dout] = fun(u)
    return out


def ptrace2(mat, dims, drop):
    keep = [j for j in range(len(dims)) if j not in drop]
    dk = s.prod(dims[j] for j in keep)
    out = s.zeros(dk)
    from itertools import product
    def flat(z):
        ans = 0
        for a, d in zip(z, dims): ans = ans*d+a
        return ans
    indices = list(product(*(range(dims[j]) for j in keep)))
    traced = list(product(*(range(dims[j]) for j in drop)))
    for ii, x in enumerate(indices):
        for jj, y in enumerate(indices):
            for zz in traced:
                aa = [0]*len(dims); bb = [0]*len(dims)
                for j, xx, yy in zip(keep, x, y): aa[j] = xx; bb[j] = yy
                for j, z in zip(drop, zz): aa[j] = bb[j] = z
                out[ii, jj] += mat[flat(aa), flat(bb)]
    return out


def transpose_output_first(mat, din=2, dout=4):
    return s.Matrix(din*dout, din*dout,
                    lambda i, j: mat[(i%dout)*din+i//dout,
                                     (j%dout)*din+j//dout])


V = s.Matrix.vstack(*(p.T for p in pauli[1:]))
assert V.H*V == 3*s.eye(2)
a = R(11, 14) + eta/2
qq = R(1, 224) - eta/4
rr = R(1, 32)
bb = R(5, 32)
core = s.zeros(8)
core[:2, :2] = a*s.eye(2)
core[:2, 2:] = bb*V.H
core[2:, :2] = bb*V
core[2:, 2:] = qq*s.eye(6) + rr*V*V.H
det2 = s.factor(a*(qq+3*rr)-3*bb**2)
assert a > 0 and qq > 0 and det2 > 0

# W|0> = |00>; W|j> = |0j>+|j0>. No irrational normalisations.
W = s.zeros(16, 4)
W[0, 0] = 1
for j in range(1, 4): W[j, j] = W[4*j, j] = 1
core_in = transpose_output_first(core)
bigW = s.kronecker_product(s.eye(2), W)
extension = bigW*core_in*bigW.H + eta*s.eye(32)/16
JE = choi(e0)
JR = choi(endpoint)
assert ptrace2(JE, [2, 4], [1]) == s.eye(2)
assert ptrace2(JR, [2, 4], [1]) == s.eye(2)
assert e0(s.eye(2)) == omega == endpoint(s.eye(2))
assert ptrace2(extension, [2, 4, 4], [2]) == JE
assert ptrace2(extension, [2, 4, 4], [1]) == JE
swap = s.zeros(32)
for u in range(2):
    for j in range(4):
        for k in range(4): swap[16*u+4*k+j, 16*u+4*j+k] = 1
assert swap*extension*swap.H == extension


def normalized(fun, x):
    # Omega^(-1/2) = sqrt(14) Q^(-1), hence no radicals survive.
    return s.simplify(14*Q.inv()*fun(x)*Q.inv())


def commutant_constraints(gens):
    units = []
    for i in range(4):
        for j in range(4):
            u = s.zeros(4); u[i,j] = 1; units.append(u)
    return s.Matrix.vstack(*(s.Matrix.hstack(*(
        s.Matrix(16, 1, list(u*g-g*u)) for u in units)) for g in gens))


def alg_dimension(fun):
    m = commutant_constraints([normalized(fun, p) for p in pauli[1:]])
    # For the cases checked here: original commutant M2 (dimension 4),
    # generic commutant scalar (dimension 1).
    return 16-DomainMatrix.from_Matrix(m).convert_to(QQ_I).rank()


assert alg_dimension(e0) == 4
assert alg_dimension(endpoint) == 1
samples = []
for j in [20, 25, 30, 40]:
    t = R(1, 2**j)
    f = lambda x: (1-t)*e0(x)+t*endpoint(x)
    assert alg_dimension(f) == 1
    assert t < R(1, 65536)
    assert ptrace2((1-t)*JE+t*JR, [2,4], [1]) == s.eye(2)
    samples.append({'t': str(t), 'commutant_dimension': 1,
                    'diamond_distance_upper_bound': str(2*t),
                    'uniform_choi_floor': '1/448'})

# Exact finite-degree exceptional-set certificate for the chosen line.
t = s.symbols('t')
gens = [(1-t)*normalized(e0,p)+t*normalized(endpoint,p)
        for p in [pauli[1],pauli[3]]]
M = commutant_constraints(gens)
M1 = M.subs(t, R(1, 2**20))
rows = list(DomainMatrix.from_Matrix(M1.T).convert_to(QQ_I).rref()[1])
cols = list(DomainMatrix.from_Matrix(M1[rows,:]).convert_to(QQ_I).rref()[1])
assert len(rows) == len(cols) == 15
minor = M.extract(rows, cols)
# Store the defining pencil and a nonzero evaluation. Expanding a symbolic
# degree-15 determinant is unnecessary for the finite-exception proof.
minor_value = QQ_I.to_sympy(DomainMatrix.from_Matrix(M1.extract(rows, cols)).convert_to(QQ_I).det())
assert minor_value != 0
poly_domain = QQ_I.poly_ring(t)
poly = poly_domain.to_sympy(DomainMatrix.from_Matrix(minor).convert_to(poly_domain).det())
poly_factored = s.factor(poly, extension=I)
quadratic = (t*t + (-R(46921,23258)+R(441,11629)*I)*t
             + R(11809,11629)-R(392,11629)*I)
assert s.expand(poly - ((-1618261995-331887829*I)/s.Integer(2)**48)
                *t**5*(t-1)**7*(t-R(182,173)-R(28,173)*I)*quadratic) == 0
assert s.simplify(quadratic.subs(t,R(8,9))) == R(1,81)

report = {
  'convention': 'input-first, unnormalised Choi',
  'status': 'EXACT_CHECKS_PASSED',
  'source_input_dimension': 2, 'source_output_dimension': 4,
  'depolarizing_delta': '1/8', 'source_choi_floor': '1/224',
  'output_state': [str(omega[j,j]) for j in range(4)],
  'core_top': str(a), 'core_q': str(qq), 'core_r': str(rr),
  'core_b': str(bb), 'core_schur_det': str(det2),
  'extension_full_choi_floor': '1/16384',
  'proved_antidegradable_diamond_ball_radius': '1/32768',
  'paired_marginals_verified': True, 'full_output_swap_verified': True,
  'endpoint_normalized_generators': {'X': str(B/16), 'Z': str(D/16)},
  'endpoint_choi_floor': '143/6272',
  'sample_perturbations': samples,
  'commutant_minor_rows': rows, 'commutant_minor_cols': cols,
  'commutant_minor_degree_upper_bound': 15,
  'commutant_minor_nonzero_evaluation_t': '1/1048576',
  'commutant_minor_nonzero_evaluation': str(minor_value),
  'commutant_minor_factored_polynomial': str(poly_factored),
  'full_algebra_for_every_real_t_in_open_unit_interval': True,
  'one_shot_ceiling_at_source_lower_bound': '29/32',
  'one_shot_ceiling_at_full_algebra_perturbations_upper_bound': '3/4',
  'ordinary_capacity_ceiling_at_source_lower_bound': '25/64',
  'ordinary_capacity_ceiling_at_full_algebra_perturbations': '0',
}
out = Path(__file__).with_name('instability_checks.json')
out.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
