"""Exact checks for the two introductory examples; requires SymPy."""
import sympy as s
I=s.I
S=s.Matrix([[3,1],[1,3]])/s.sqrt(10)
omega=s.Matrix([[1,s.Rational(3,5)],[s.Rational(3,5),1]])
assert s.simplify(S*S)==omega
r0=S*s.diag(1,0)*S
r1=S*s.diag(0,1)*S
assert r0==s.Matrix([[9,3],[3,1]])/10
assert r1==s.Matrix([[1,3],[3,9]])/10
assert (r0-r1).eigenvals()=={s.Rational(4,5):1,-s.Rational(4,5):1}
X=s.Matrix([[0,1],[1,0]])
Y=s.Matrix([[0,-I],[I,0]])
Z=s.diag(1,-1)
assert s.trace((X/4)*(Y/4)*(Z/4))/2==I/64
assert s.trace((X.T/4)*(Y.T/4)*(Z.T/4))/2==-I/64
# A faithful reference-valued example with noncommuting reference blocks.
ref_a=s.Matrix([[3,1],[1,2]])
ref_b=s.Matrix([[2,I],[-I,4]])
e0=s.diag(1,0);e1=s.diag(0,1)
rho=(s.kronecker_product(e0,ref_a)+s.kronecker_product(e1,ref_b))/11
tangent=s.kronecker_product(e0,X)+s.kronecker_product(e1,Z)
f_rho=(s.kronecker_product(r0,ref_a)+s.kronecker_product(r1,ref_b))/11
f_tangent=s.kronecker_product(r0,X)+s.kronecker_product(r1,Z)
assert rho.det()>0 and f_rho.det()>0
assert s.simplify(s.trace(tangent*rho.inv()*tangent)
                 -s.trace(f_tangent*f_rho.inv()*f_tangent))==0
print("Exact worked examples: passed")
