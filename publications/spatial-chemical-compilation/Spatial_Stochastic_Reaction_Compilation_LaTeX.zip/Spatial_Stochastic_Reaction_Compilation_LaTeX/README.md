# Spatial Compilation of Stochastic Chemical Trajectories

Harjas Sandhu — The University of Queensland — 13 November 2026.

Build from this directory with an installed TeX distribution providing
pdfLaTeX, latexmk, AMS packages, Latin Modern, microtype, hyperref, cleveref
and TikZ:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

No network access, external graphics, shell escape, bibliography download or
BibTeX pass is required. `references.tex` is the typeset bibliography;
`references.bib` provides the same records for reuse. Both figures are native
TikZ sources in `figures/` and are included by the section sources.

`preamble.tex` contains notation and document setup. `sections/` contains the
main argument and `appendices/` contains the longer reflection, mixing,
finite-bit and import details. The standalone deliverable expands all these
inputs, including the bibliography and figures, into one `.tex` file.

The central theorem concerns a conservative reversible target and an ideal
finite-radius continuum model, with task-dependent severe dilution,
slowdown and precision permitted. The public kinetic dependency is
Theorem 9.1 of *Compiling Stochastic Chemical Trajectories with Elementary
Reactions*, version 1.0, doi:10.5281/zenodo.24170339. That theorem is proved
independently of this spatial paper. The general open kinetic main theorem
is not the balance interface.

The presence of source files and a compiled PDF does not imply an executed
particle-system compiler, physical device, experiment or practical advantage.
