# Quantum Memory from Rare Thermal Boundaries

Harjas Sandhu, The University of Queensland. 6 November 2026.

This directory contains the complete modular LaTeX source. The bibliography
is included in bibliography.tex; the conceptual diagram is native TikZ
in sections/02-overview.tex. There are no external figure assets or
private bibliography dependencies.

Build with a current TeX Live or MacTeX installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The independently buildable, flattened source and finished PDF are supplied
beside this directory as Quantum_Memory_from_Rare_Thermal_Boundaries.tex
and Quantum_Memory_from_Rare_Thermal_Boundaries.pdf.

The paper proves abstract exact-dynamics storage criteria and records their
access assumptions and limitations. It does not claim a new local 3D
construction, an efficient resource-preparation algorithm, or a generic
noisy-writing threshold.
