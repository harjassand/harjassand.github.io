# Limitations and further questions

The reconstruction theorem and its block-game consequence have different scopes. Exact positive fractional rectangle partitions exist for all finite Boolean predicates, so the charged scalar inequality is general. Quadratic repetition follows when the presentation charge vanishes, or more generally when it is controlled by the gap. The proof does not show that a general predicate admits such a presentation. A state-sensitive entropy allocation that avoids the positive-presentation charge remains the decisive missing operation for arbitrary-predicate quadratic repetition.

The weighted threshold estimate has a fifth-power deviation rate. The present argument does not identify that power as optimal. Likewise, the heterogeneous intrinsic exponent
\[
 \sum_i\frac{\epsilon_i^3}{\epsilon_i+\kappa_i}
\]
is not proved without a uniform charge-to-gap bound. Bounds for separate groups cannot simply be multiplied, since the repeated strategy may correlate their outputs.

Two elementary counterexamples delimit the communication and reconstruction interfaces. First, reveal a uniform \(n\)-bit string completely with probability \(1/n\), and reveal nothing otherwise. Expected communication is one bit, and the mutual information is \(\log2\), but the guessing probability is at least \(1/n\). Expected communication or Shannon leakage alone cannot preserve an exponential soundness guarantee. The finite-order conditions in Section 8 carry indispensable tail information.

Second, take independent uniform bits \(X,Y,A,B\) and condition on \(A\oplus B=XY\). The event has probability \(1/2\) for every input, so the question law is unchanged. Nevertheless the conditioned box wins CHSH perfectly, whereas its commuting value is at most \((2+\sqrt2)/4\). Small question drift alone therefore does not legalize postselection. Our reconstruction pays both preparation deficits and the unconditional question-law cost.

Finally, repetition is not a locality-preserving Hamiltonian construction. It does not by itself provide bounded local consistency tests, an acquired finite encoding, a controlled energy normalization or an efficient honest implementation. Nor does it supply uniform polynomial-size certificates for cryptographic compilation of a growing family of games. These require additional constructive theorems. The noisy-channel application is an information-theoretic statement for its stated protocol model, rather than an implemented device advantage.

\section*{Acknowledgements and AI use}
The mathematical ideas, constructions, proofs, and manuscript were developed by GPT-6 Astra, with additional AI assistance for review. Human input was minimal and consisted primarily of setting the research objectives and providing occasional feedback.

\appendix

# Operational tracial correlated sampling

We give the sampler needed in Section 4, including its losing-event estimate. Smooth logarithmic labels and first-success sampling are adapted from Song \cite[Lemma 4.1]{Song}. The finite-tracial implementation below uses graph projections and keeps all output branches.

Let \((\mathcal M,\tau)\) be finite with faithful normal tracial state. Let \(a_x,b_y\) be finite families of unit \(L^2(\mathcal M,\tau)\) vectors, and let \(A_x^s,B_y^t\) be complete finite POVMs in \(\mathcal M\), represented on the left and right, respectively. For a law \(\nu\), put
\[
 D=\mathbb E_\nu\|a_x-b_y\|_2^2,\qquad
 p_{xy}(s,t)=\langle a_x,L(A_x^s)R(B_y^t)a_x\rangle .
\]
The sampler supplies one input-independent resource in a finite amplification and tensor power, and complete all-input commuting POVMs. More precisely, for \(0<h<1/2\), bounded finite-spectrum approximations of accuracy \(\eta>0\), and timeout parameter \(\xi>0\), its actual loss obeys
\[
 \beta\le\alpha+2\sqrt{\alpha F}+F,\qquad
 F=896\left(h^2+\frac{2D+8\eta^2}{h^2}\right)+3\eta^2+\xi ,
 \tag{A.1}
\]
where \(\alpha\) is the loss of the declared target table and the losing effect may depend arbitrarily on \(x,y\). All approximation and timeout parameters are chosen before the realized questions.

## Spectral coupling and finite approximations

For spectral decompositions \(c=\sum_i\lambda_iE_i\), \(d=\sum_j\mu_jF_j\), tracial orthogonality gives
\[
 \left\|\sum_{ij}z_{ij}E_iF_j\right\|_2^2
       =\sum_{ij}|z_{ij}|^2\tau(E_iF_j).
 \tag{A.2}
\]
Indeed left orthogonality removes unequal \(i\), and trace cyclicity removes unequal \(j\). The coefficients \(\tau(E_iF_j)\) are nonnegative and have the correct spectral marginals. Applying this coupling to self-adjoint dilations
\[
 Z_a=\begin{pmatrix}0&a\\a^*&0\end{pmatrix}
\]
and the scalar \(1\)-Lipschitz map \(t\mapsto|t|\) gives
\[
 \||a^*|-|b^*|\|_2^2\le2\|a-b\|_2^2. \tag{A.3}
\]
No commutation of \(a,b\) is required.

Approximate each vector by a bounded element, normalize, take its polar decomposition and approximate its positive left modulus by a finite spectral step function. The interval nearest zero may be set to zero. Normalizing again gives unit approximations \(\bar a_x,\bar b_y\), of error at most \(\eta\), with finite-spectrum left moduli. Since the input families are finite, all choices can be made together. Their mean discrepancy satisfies
\[
 \bar D\le2D+8\eta^2. \tag{A.4}
\]

## Smooth labels and graph projections

For \(\lambda>0\), set \(s=-\log\lambda/h\), \(k=\lfloor s\rfloor\), \(t=s-k\), and
\[
 g_\lambda=\cos(\pi t/2)|k\rangle+\sin(\pi t/2)|k+1\rangle.
\]
Use one finite integer interval covering every positive spectral value of the approximating family, and add an orthogonal label \(o\). Negative integers are allowed. Set
\[
 T=\sum_k e^{-kh}e_{kk}\otimes1,\quad T|o\rangle=0,\quad
 S=(\operatorname{Tr}_l\otimes\tau)(T^2),\quad
 \Omega=T/\sqrt S .
\]
The label space and \(\Omega\) depend on the finite family, not on the realized input. Direct scalar estimates give
\[
 \|(T-\lambda)g_\lambda\|\le2h\lambda,\qquad
 \lambda\mu(1-|\langle g_\lambda,g_\mu\rangle|^2)
       \le\pi^2(\lambda-\mu)^2/h^2, \tag{A.5}
\]
and
\[
 \mu|1-\langle g_\lambda,g_\mu\rangle|
       \le\pi|\lambda-\mu|/h.
\]
For the latter estimates use the speed \(\pi/2\) of the label curve when the logarithmic separation is at most \(h\); otherwise use the trivial overlap bound and
\(|\lambda-\mu|\ge\max(\lambda,\mu)h/2\).
Zero coefficients have zero multiplier and are omitted from the following graph maps.

For a fixed approximating pair \(a,b\), put \(c=|a^*|\), \(d=|b^*|\), \(b=du\). Define in \(\mathcal K=M_l\otimes\mathcal M\)
\[
 F_c=\sum_k e_{ko}\otimes g_k(c),\quad P_c=F_cF_c^*,\qquad
 F_d=\sum_k e_{ko}\otimes g_k(d),\quad P_d=F_dF_d^*.
\]
Here \(g_k(0)=0\). These are graph partial isometries and projections. Alice's success coefficient is \(K_A=F_c^*\); Bob's is
\(K_B=F_d(e_{oo}\otimes u)\). Thus
\[
 K_A^*K_A=P_c,\qquad K_BK_B^*=P_d.
\]
The reversed Bob order is essential because \(R(v)R(w)=R(wv)\).

Write, using the unnormalized matrix trace,
\[
 A=\|P_cT\|_2^2,\quad B=\|TP_d\|_2^2,\quad
 C=\|P_cTP_d\|_2^2,\quad U=A+B-C.
\]
Their normalized values are the local success, joint success and union probabilities. Trace cyclicity gives the exact identity
\[
 m=A+B-2C=\|P_cT-TP_d\|_2^2,\qquad
 U\ge\max(A,B)\ge e^{-2h}. \tag{A.6}
\]
If \(\Delta=\|a-b\|_2^2\) and \(r=h^2+\Delta/h^2\), then (A.2)--(A.5) give
\[
 m\le128r,\qquad
 K_ATK_B=e_{oo}\otimes x,\qquad
 \|x-b\|_2^2\le40r. \tag{A.7}
\]
For clarity, the two spectral calculations behind these constants are
\[
 \|F_ccF_c^*-F_ddF_d^*\|_2^2
 =\sum_{ij}\bigl[(\lambda_i-\mu_j)^2+
 2\lambda_i\mu_j(1-|\langle g_{\lambda_i},g_{\mu_j}\rangle|^2)\bigr]
 \tau(E_iF_j)
\]
and
\[
 x=\sum_{ij}\langle g_{\lambda_i},Tg_{\mu_j}\rangle E_iF_ju.
\]
Each of \(\|P_cT-F_ccF_c^*\|_2^2\) and
\(\|TP_d-F_ddF_d^*\|_2^2\) is at most \(4h^2\). The three-term squared triangle inequality and (A.3) give
\(m\le24h^2+6\Delta+12\pi^2\Delta/h^2\le128r\).
For the second calculation the coefficient error is at most
\(8h^2\mu_j^2+2\pi^2(\lambda_i-\mu_j)^2/h^2\), giving
\(\|x-b\|_2^2\le8h^2+4\pi^2\Delta/h^2\le40r\).
If \(C>0\), the normalized vector \(v=x/\sqrt C\) satisfies
\(\|v-b\|_2\le2\sqrt{40r}\). Its conditional output uses the original fine POVMs after local label erasure.

## Complete finite first-success protocol

Use \(N=\lceil e^{2h}S\log(2/\xi)\rceil\) independent copies of \(\Omega\). Each player keeps its first local success, with a fixed default answer on timeout. Alice's underlying effects are
\[
 E_x^s=\sum_{j=1}^N(1-P_c)^{\otimes(j-1)}
 \otimes[K_A^*(I_l\otimes A_x^s)K_A]\otimes1^{\otimes(N-j)}
 +\mathbf1_{s=s_0}(1-P_c)^{\otimes N}.
\]
Bob's underlying effects are
\[
 F_y^t=\sum_{j=1}^N(1-P_d)^{\otimes(j-1)}
 \otimes[K_B(I_l\otimes B_y^t)K_B^*]\otimes1^{\otimes(N-j)}
 +\mathbf1_{t=t_0}(1-P_d)^{\otimes N}.
\]
They are positive and sum to identity by telescoping. The physical effects are \(L_N(E_x^s)\) and \(R_N(F_y^t)\). They commute for every pair of inputs, even when the retained trial indices differ.

Independence of trials gives the exact probability of a common retained index:
\[
 w_{\mathrm{same}}=\frac C U[1-(1-U/S)^N],\qquad
 1-w_{\mathrm{same}}\le e^{2h}m+\xi\le384r+\xi. \tag{A.8}
\]
On that branch the output is the table on \(v\). Every other branch is a genuine output branch and is charged loss at most one.

For the original target \(a_x\), the approximation and (A.7) give
\[
 \|v-a_x\|_2^2\le512r_{xy}+3\eta^2 .
\]
For a positive losing effect \(0\le M_{xy}\le I\), the triangle inequality for \(M_{xy}^{1/2}\) gives its synchronized loss at most
\((\sqrt{\alpha_{xy}}+\sqrt{512r_{xy}+3\eta^2})^2\).
Combining with (A.8), and then Cauchy--Schwarz in the average, proves (A.1). If \(C=0\), the entire branch is charged, and the same upper bound holds. This proof controls a rare losing event for the actual unconditional POVMs, not merely a mean total-variation distance.

All approximations, label ranges and trial counts are finite at fixed positive parameters. One first chooses \(h>0\), then sufficiently small \(\eta,\xi\). At zero discrepancy one takes positive \(h\) tending to zero with those inner errors. No inverse spectral gap, zero-width label or infinite-time protocol is used.

# Register placement and entropy allocation

We record the register assignment behind Section 5. This makes clear why the two comparison states concern the same target and why the shared history need not be sampled independently.

Fix tested questions \(c\) and a successful label \(l\). Keep three copies of the label on each target side. Each residual workspace \(E_A,E_B\) retains its own private copy and all its original fine outputs. Partition the other four copies as
\[
 H_{A,\mathrm{label}}=(L_A^1,L_B^3),\qquad
 H_{B,\mathrm{label}}=(L_B^1,L_A^3).
\]
They contain identical values on the accepted target. All four external copies are omitted from the comparison parents; otherwise a Bob-created label in Alice's reference could destroy its conditional form.

For live \(i\), the histories and residual bodies are
\[
\begin{aligned}
 H_{A,i}&=(c,H_{A,\mathrm{label}},\widehat Y_{<i},X_{>i}),&
 A_i^0&=\widehat X_{<i}X_{<i}E_A,\\
 H_{B,i}&=(c,H_{B,\mathrm{label}},Y_{<i},\widehat X_{>i}),&
 B_i^0&=\widehat Y_{>i}Y_{>i}E_B .
\end{aligned}
\]
Together with \(\widehat X_i,X_i,\widehat Y_i,Y_i\), these partition one pure vector. Redundant equal history copies can be suppressed by fixed isometries. The original coordinate answer is read from its local retained fine-output record.

The ordered restrictions on Alice's comparison trace the later protected references and expose only \((Y_{<i},X_{>i})\); Bob uses the reverse orientation. These restrictions act outside the fresh protected reference and hence commute with attaching its original conditional-question amplitudes. For each orientation the relative-entropy increments telescope:
\[
 \sum_i\bigl[D(\rho^{R_{\le i}K}\Vert\nu^{R_{\le i}K})
             -D(\rho^{R_{<i}K}\Vert\nu^{R_{<i}K})\bigr]
 =D(\rho^{RK}\Vert\nu^{RK})-D(\rho^K\Vert\nu^K).
\]
Direct-sum relative entropy identifies each exposed classical branch with the corresponding expected coordinate deficit. This is the ordered copied-reference identity of Jain \cite[Lemma 2.24]{Jain}; no finite-dimensional entropy subtraction is required, since all displayed relative entropies are finite by domination. The private label in \(K\) makes its additional conditional mutual information zero.

Finally, apply reconstruction to the whole \(x_i,y_i\)-indexed pure target, with the histories included in its output workspace. They are not first sampled from a posterior law. The separately charged question divergence is the unconditional \(D(q_i\Vert\mu_i)\). In particular, conditioning a history that reveals the fresh question does not create an uncharged external source.

Finite target ancillas can all be embedded in one common standard form. For
\(\psi=\sum_{ab}|a\rangle|b\rangle w_{ab}\), map it to
\[
 \sqrt{d_Ad_B}\sum_{ab} e_{a1}\otimes e_{1b}\otimes w_{ab}
 \ \in L^2(M_{d_A}\otimes M_{d_B}\otimes\mathcal M),
\]
with normalized matrix traces. Alice's matrix acts on the left first factor and Bob's transposed matrix on the right second factor. For operator-valued Bob matrices the transpose accompanies the opposite coefficient algebra; this is the canonical opposite-algebra isomorphism, not a positive-partial-transpose assumption. Thus every assignment above has exact all-input left/right locality.
