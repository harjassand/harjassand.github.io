# Finite resources and the operational interface

The reconstruction theorem supplies a legal strategy at each positive accuracy. It does not supply a uniform implementation cost. Its finite matrix amplifications add ordinary finite ancillary records; finite tensor powers permit independent first-success trials. The original finite von Neumann algebra remains present. When it is infinite dimensional, the resulting strategy need not have a finite matrix realization.

This distinction is also needed in an abelian algebra. Let \(\mathcal M=\mathbb C^2\), with equal trace weights, and let the two possible target vectors be \(\sqrt2e_0\) and \(\sqrt2e_1\). An algebra-local trace-preserving channel with Kraus coefficients in \(\mathcal M\) fixes every central projection in the adjoint picture:
\[
 \sum_j K_j^*zK_j=z\sum_jK_j^*K_j=z.
\]
It cannot move the fixed central weights of one resource to either requested sector. This rules out a stronger output-channel interpretation of reconstruction.

Finite first-success selection avoids that obstruction. Independent copies of the tracial resource contain independent central samples. When the players request the same sector, their local success predicates agree on every trial. After \(N\) trials their common failure probability is \(2^{-N}\), and the chosen copy is in the requested sector. The resulting output probabilities arise from complete POVMs on the amplified resource. On nonsynchronized branches there is no promised state in the original algebra.

More generally, if the finite spectral approximations in Appendix A have largest positive singular value \(B_0\) and smallest \(\delta_0\), the label count and trial count can be chosen with
\[
 l\le\left\lceil\frac{\log(B_0/\delta_0)}h\right\rceil+4,\qquad
 S\le\frac{e^{2h}B_0^2}{1-e^{-2h}},\qquad
 N=\left\lceil e^{2h}S\log(2/\xi)\right\rceil .
\]
The error constant is uniform, but these resources need not be. No efficient acquisition of spectral data for an arbitrary von Neumann algebra is assumed.

Consequently the finite-table closure used in Section 6 is applied to scalar probabilities only. It neither preserves the constructed descriptors nor gives a finite-dimensional approximation to an arbitrary commuting strategy. The separate tensor theorem avoids this issue by beginning in matrices and remaining there.
