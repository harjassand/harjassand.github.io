
# Introduction

Independent tests need not produce independent successes. In a two-player game, each player sees only one part of a question pair and returns an answer without communicating. Even when a referee repeats the experiment with independent questions, the players may use a single joint strategy for the entire string. Parallel repetition asks how quickly the probability of passing every test must fall.

The issue becomes especially delicate for commuting-operator strategies. Here the two players' measurements commute, but they need not act on separate finite-dimensional tensor factors. Finite-dimensional entanglement is a special case. A proof that uses Schmidt decompositions, or approximates a finite tracial algebra by matrices without justification, does not automatically cover this larger model.

We prove a quadratic-gap repetition bound for games whose winning answer graphs are unions of disjoint complete bipartite blocks. This includes projection predicates with noninjective or partially defined maps. The central construction is more general: an exact positive rectangle partition gives one refined conditioned target and two separately normalized one-sided comparison states. Their entropy deficits can be allocated to the untested coordinates. A local reconstruction theorem in finite tracial standard form turns this information bound into legal strategies. Only after eliminating those strategies into scalar inequalities do we pass to arbitrary commuting correlations.

## Main results

A finite Boolean game is a tuple \(G=(X,Y,A,B,\mu,V)\), where all four alphabets are finite and nonempty, \(\mu\) is a probability law on \(X\times Y\), and \(V:X\times Y\times A\times B\to\{0,1\}\). Write \(\omega_{\mathrm{co}}\) for the commuting value and \(\omega_*\) for the supremum over finite-dimensional tensor strategies. A winning mask is **disjoint-block** if its nonisolated bipartite components are complete bipartite graphs.

\begin{theoremA}
Suppose every supported winning mask of \(G\) is disjoint-block. If
\(\epsilon=1-\omega_{\mathrm{co}}(G)\), then, for every integer \(n\ge1\),
\[
 \omega_{\mathrm{co}}(G^{\otimes n})
       \le \exp(-2^{-75}\epsilon^2n). \tag{A}
\]
The questions may be arbitrarily correlated within each round. The rounds are independent, and the repeated strategy is an arbitrary joint commuting strategy. Separately, the same bound holds for \(\omega_*(G^{\otimes n})\) with its own gap \(\epsilon_*=1-\omega_*(G)\).
\end{theoremA}

No dimension or resource-size bound is asserted. The proof for the tensor gap is carried out in matrices throughout; it is not obtained by substituting \(\epsilon_*\) into a commuting-value inequality. The original binary line games of Kempe and Regev \cite[Definition 3.1 and Theorems 3.2, 4.4]{KR} belong to the full disjoint-block class and show that the power two is optimal there, up to constants. Their endpoint constraints are partial, so this example alone does not settle optimality for total projections.

A second result connects zero-communication soundness with noisy information flow. It uses ordinary finite-dimensional quantum communication; its baseline may be any commuting-value upper bound.

\begin{theoremB}
Let \(H\) be a finite Boolean game and \(q_0=\omega_{\mathrm{co}}(H)\). Suppose finite-dimensional quantum players start with arbitrary shared entanglement independent of the referee questions. They may communicate through a prescribed finite sequence of fixed memoryless channels \(\mathcal N_1,\ldots,\mathcal N_m\), in either direction, with arbitrary local adaptation. Every cross-player signal is included. For every \(\alpha>1\),
\[
 p_{\mathrm{accept}}\le
 \min\left\{1,\exp\left(\frac{\alpha-1}{\alpha}
 [\log q_0+\sum_j I_\alpha(\mathcal N_j)]\right)\right\}. \tag{B}
\]
The reference-marginal-fixed channel information \(I_\alpha\) is defined in (8.1). One common order \(\alpha\) is used for all terms.
\end{theoremB}

Thus an exponential repetition bound can remain exponential in the presence of interactive noisy communication. This statement follows from established replacer-radius and amortization theorems; the contribution is their application at this game interface. We give a source-correlation extension and an explicit erasure-channel example with fully stated coding costs.

## Predecessors and the precise contribution

For unique games, quadratic repetition is already a consequence of the semidefinite-product and rounding machinery of Kempe, Regev and Toner \cite[SDP 3, Lemma 5.7, Theorems 5.2 and 5.5]{KRT}. Commuting strategies supply feasible Gram vectors for that SDP, and its rounding supplies finite tensor strategies. We make no novelty claim for that restriction. Dinur, Steurer and Vidick \cite[Theorem 1, version 2]{DSV} proved exponential repetition for entangled projection games through a multiplicative relaxation; the general gap power in that result is at most twelve, with a stronger linear-gap conclusion for expanding question graphs.

Song's cubic entangled repetition theorem and smooth correlated sampler \cite[Lemma 4.1]{Song}, and Jain's conditional-relative-entropy proof \cite[Definitions 2.6, 2.8; Lemmas 2.24--2.25 and 4.1--4.2]{Jain}, are direct methodological predecessors. We use the copied-question and conditional-comparison framework, but replace finite-dimensional purification arguments by explicit finite-algebra matrices and local polar corrections. The smooth sampler is implemented through tracial graph projections and finite first-success trials; its operational proof is included in Appendix A.

The multivariate trace inequality of Junge and LaRacuente \cite[Theorem I.2 and Lemma VI.2]{JL} supplies the exact-marginal replacement step. Lin's full finite-table closure theorem \cite[Definition 3.1 and Theorem 3.2]{LinTr} then transfers scalar inequalities from finite-tracial strategies to arbitrary commuting strategies. A finite tracial algebra can be infinite dimensional; neither result is a matrix-density statement.

The new construction is the common square-root-weighted target together with two independently normalized one-sided comparisons. They need not be marginals of one common preselection state. Retaining a private copy of the label makes the relevant conditional entropy term cancel exactly. This proves the coordinate reconstruction condition stated as a hypothesis in the earlier entropy-budget paper \cite{Sandhu}. Heterogeneous all-wins and weighted-threshold estimates are consequences of that reconstruction and the scalar allocation argument, rather than separate reconstruction mechanisms.

The communication application uses Gupta and Wilde's replacer-radius identity \cite[Lemma 5]{GW} and Wilde, Berta, Hirche and Kaur's amortization collapse \cite[Proposition 41]{WBHK}. The erasure coding exponent is consistent with the exact strong-converse theorem of Li and Yao \cite[Theorem 6]{LY}; no new channel capacity theorem is claimed.

# Conceptual overview

Conditioning on successful tests is powerful and dangerous. It exposes a workspace in which untested answers can look better than any legal one-round strategy. The proof must reconstruct that workspace from a resource chosen before the fresh question arrives. Merely showing that the fresh question law changes little does not suffice.

The argument has five steps. First, resolve the tested winning relation into positive rectangles. Second, coherently record a common rectangle label with amplitude equal to the square root of its weight. Third, compare the resulting single target to two different one-sided positive states. Fourth, allocate the information lost when question references are discarded. Finally, convert small coordinate deficits into one-round strategies. If too many coordinates became too easy at a small conditioning cost, one of those reconstructed strategies would beat the base-game value.

\begin{figure}[ht]
\centering
\begin{tikzpicture}[node distance=5mm,
 box/.style={draw=deepteal,rounded corners,align=center,text width=.76\linewidth,inner sep=6pt,font=\small},
 >=Stealth]
\node[box] (a) {Independent question pairs; a joint repeated strategy};
\node[box,below=of a] (b) {Checked wins; one exact square-root-weighted target};
\node[box,below=of b] (c) {Two one-sided comparisons; private-label entropy cancellation};
\node[box,below=of c] (e) {Coordinate deficits; legal local reconstruction};
\node[box,below=of e] (f) {A contradiction to the base gap; exponential repetition};
\foreach \u/\v in {a/b,b/c,c/e,e/f}\draw[->,deepteal] (\u)--(\v);
\end{tikzpicture}
\caption{The proof transfers a conditioned answer table to a legal strategy. It does not interpret postselection itself as a physical protocol.}
\end{figure}

## A small example: why the weights occur only once

Consider the mask
\[
 V=\begin{pmatrix}1&1\\1&0\end{pmatrix}.
\]
It has four rectangles of weight \(1/2\): the full first row, the full first column, the singleton upper-right cell and the singleton lower-left cell. Every winning cell is covered with total weight one, while the losing cell is uncovered. The maximum row and column loads are both \(3/2\).

For a fine outcome \((a,b)\), give the common target an orthogonal label \(l\) with coefficient
\(\sqrt{w_l}\mathbf1_{R_l}(a)\mathbf1_{T_l}(b)\).
The squared norm, summed over labels, is exactly \(V(a,b)\). Both players' original output records can therefore be retained without changing any conditioned measured probability.

Applying two weighted local filters simultaneously would instead multiply the coefficients and produce \(w_l^2\) in the probability. In this example each accepted cell would acquire total weight \(1/2\), not one. The correct construction uses two different comparison states, each of which contains one factor \(\sqrt{w_l}\), against the same target. The comparisons are mathematical witnesses; there is no requirement to apply both filters to a physical resource.

For a disjoint-block mask there is a unique accepted block label, and both load bounds are one. This removes the presentation charge and is exactly where the quadratic gap rate enters. For a general mask the charge can remain positive even when the game gap is small.

## Two distinctions to keep in view

All local measurements produced by reconstruction are complete on every input pair, not only on sampled or synchronized pairs. Sampling failures are charged as actual output branches. And the limiting step concerns finite probability tables: the prepared vectors, algebras and operational witnesses are eliminated before Lin's closure theorem is invoked.
