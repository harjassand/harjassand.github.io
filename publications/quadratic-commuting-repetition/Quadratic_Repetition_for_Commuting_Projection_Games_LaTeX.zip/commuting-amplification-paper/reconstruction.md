# Model and the reusable reconstruction theorem

A commuting strategy uses a unit vector \(\psi\), complete finite POVMs \(P_a^x,Q_b^y\), and
\([P_a^x,Q_b^y]=0\) for every input/output pair. Its payoff is
\(\sum\mu(x,y)V(x,y,a,b)\langle\psi,P_a^xQ_b^y\psi\rangle\).
No optimizer is assumed. In a repeated game each POVM can depend on the entire local question string.

All logarithms are natural. A density is a positive element of trace one; finite classical records use the ordinary sum trace. We use \(\|a\|_p=\tau(|a|^p)^{1/p}\). For bounded densities,
\[
 D(\rho\Vert\nu)=\tau\bigl(\rho(\log\rho-\log\nu)\bigr)
\]
is the Umegaki relative entropy, with its support-restricted extended-value interpretation. Every difference of divergences below is formed only when both terms are finite. Root fidelity is \(F(\rho,\nu)=\|\sqrt\rho\sqrt\nu\|_1\), and purified distance for normalized states is \(P(\rho,\nu)=\sqrt{1-F(\rho,\nu)^2}\). Data processing means that discarding a register cannot increase relative entropy or purified distance.

First work in finite-tracial standard form:
\[
 (\mathcal M,\tau),\qquad
 \mathcal H=L^2(\mathcal M,\tau),\qquad
 \sigma\in\mathcal M_+,\quad\tau(\sigma^2)=1.
\]
Alice acts by \(L(a)\xi=a\xi\), Bob by \(R(b)\xi=\xi b\). The right representation is opposite, and commutes with the left representation on every input. The finite von Neumann algebra can be infinite dimensional. Boundedness of \(\sigma\) is part of this starting representation. Subsequent finite amplifications and finite tensor powers preserve that setting.

## Conditional comparisons

A question reference is a bookkeeping copy that records how the target depends on the input. It is not a message supplied to a player. Keeping one copy coherent lets us ask whether that dependence can be explained by the original conditional question law and a state prepared on just one side.

The comparison below has exactly that form: its seed contains Alice's local input and workspace, and the factors involving Bob's input come only from the referee's original conditional law. Crucially the seed may have its own local input marginal. Requiring that marginal to agree with the conditioned target would unnecessarily exclude the actual-mass normalization used later.

Let \(\mu\) be a probability law on finite \(X\times Y\), and let \(q\) be supported on its support. Consider bounded unit vectors \(\psi_{xy}\in L^2(\mathcal N)\) in a finite tracial algebra. They determine a copied-input pure family
\[
 \sum_{x,y}\sqrt{q(x,y)}
 |x\rangle_{\widehat X}|x\rangle_X
 |y\rangle_{\widehat Y}|y\rangle_Y\psi_{xy}. \tag{3.1}
\]
Its Alice marginal is classical in \(\widehat Y\); in each \(y\) block its coherent \(x,x'\) entries are
\[
 \sqrt{q(x,y)q(x',y)}\,\psi_{xy}\psi_{x'y}^*.
\]
Matching \(\widehat X=X\) copies are understood.

For any positive normalized seed \(T=[T_{xx'}]\) over \(\mathcal N\), an **Alice conditional comparison** has entries
\[
 (\nu_A)_{y;xx'}
 =\sqrt{\mu(y|x)\mu(y|x')}\,T_{xx'}. \tag{3.2}
\]
The seed's local \(X\) law is arbitrary on the supported symbols. It need not equal \(q_X\). Bob's comparison is defined by reversing the roles and working over the opposite algebra. These are two separately chosen comparisons for the **same target**; they need not be margins of a common reference state.

Let \(K_A=XA\), \(K_B=YB\), including all designated residual workspaces. With finite full divergences, define
\[
 b_A=D(\rho_A\Vert\nu_A)
       -D(\rho_A^{K_A}\Vert\nu_A^{K_A}),\quad
 b_B=D(\rho_B\Vert\nu_B)
       -D(\rho_B^{K_B}\Vert\nu_B^{K_B}). \tag{3.3}
\]
The deficit measures the distinguishability that disappears when the protected question reference is discarded. Data processing makes it nonnegative. A small value says that the reference adds little information beyond the retained local workspace, which is the condition needed for approximate local preparation. The Alice and Bob deficits test different one-sided explanations of the same target.

All quantities are relative-entropy differences of finite displayed values. Infinite individual entropies are not subtracted.

## Operational reconstruction

\begin{theoremC}
Under the preceding finite-input, bounded-vector, support, comparison-form, and finite-divergence assumptions, fix finite local/opposite fine POVMs and a Boolean losing predicate. Let \(\alpha\) be its mean loss on the target under \(q\). Put
\[
 t=b_A+b_B+D(q\Vert\mu).
\]
For every \(\zeta>0\), there is one shared resource fixed before the inputs arrive and complete commuting POVMs on \emph{every} local input pair, with loss under \(\mu\) at most
\[
 \boxed{\alpha+K\big(\sqrt\alpha\,t^{1/4}+\sqrt t\big)+\zeta,
 \qquad K=65536.} \tag{3.4}
\]
The resource is a finite amplification and finite tensor power of the original finite algebra. It need not be finite dimensional. The construction preserves the declared fine measurement interface, not an output channel onto the original algebra. Its resource parameters can depend on the entire finite family, spectra, and accuracy; there is no uniform size bound.

\end{theoremC}

The statement does not require a game mask or a repeated-game structure. We prove it next.

# Proof of Theorem C

There are three operations. We first replace a conditional comparison by one having exactly the target's retained marginal, while controlling fidelity by the entropy deficit. We then realize the resulting alignment by local polar corrections in a single amplified algebra. Finally, the correlated sampler turns those local descriptions into actual commuting measurements. The losing-event estimate is kept in square-root form so that a nearly perfect target does not pay a generic total-variation error.

## Exact marginal replacement at positive faithful slack

Write \(r=\rho_K,n=\nu_K\). For Alice, the supported full algebra is \(\bigoplus_{y:\mu_Y(y)>0}M_{X_y}(\mathcal N)\), \(X_y=\{x:\mu(x,y)>0\}\), with the matching fresh-question copies understood; the retained marginal is block diagonal in \(X\). Bob uses the reversed supported corner. Start with boundedly invertible densities there. Set
\[
 L_s=r^{(1+is)/2}n^{-(1+is)/2},\qquad
 \widetilde\nu=\int_{\mathbb R}\beta_0(s)L_s\nu L_s^*\,ds,
\quad
 \beta_0(s)=\frac{\pi}{2(\cosh(\pi s)+1)}. \tag{4.1}
\]
The integral is normal and all inverse powers are bounded. Its retained marginal is exactly \(r\), since \(L_snL_s^*=r\) pointwise. Because \(K\) is classical in the local question control \(X\), \(L_s\) is \(X\)-block diagonal and commutes with the scalar conditional-amplitude factors in (3.2). Thus \(\widetilde\nu\) remains a conditional comparison. If \(\nu\ge c_\nu I\), \(r\ge c_rI\), and \(n\le M_nI\), then \(\|L_s^{-1}\|\le\sqrt{M_n/c_r}\) uniformly in \(s\), and \(\widetilde\nu\ge(c_\nu c_r/M_n)I\). The following faithful-density arguments therefore apply also to the replacement.

The finite-tracial specialization of Junge--LaRacuente's Theorem I.2 \cite{JL} gives, for positive invertible \(W\),
\[
 \tau e^{\log W+\log r-\log n+\log\nu}
 \le\int\beta_0(s)\tau(WL_s\nu L_s^*)\,ds. \tag{4.2}
\]
The operator order in this formula is essential. Apply their \(p=2\) inequality to half-logarithms and then scalar Jensen; cyclicity removes the endpoint imaginary powers. This is a primary-source trace-inequality import over general von Neumann algebras, not a matrix-approximation argument.

The Gibbs variational formula and (4.2) imply
\[
 b=D(\rho\Vert\nu)-D(r\Vert n)
 \ge \tau(\rho\log W)+1-\tau(\widetilde\nu W).
\]
Taking the supremum is the measured-relative-entropy variational formula, hence
\[
 D_{\mathrm{meas}}(\rho\Vert\widetilde\nu)\le b,\qquad
 F(\rho,\widetilde\nu)^2\ge e^{-b}. \tag{4.3}
\]
Here \(F(a,b)=\|\sqrt a\sqrt b\|_1\) is root fidelity.

The second inequality is valid in finite trace without a dimension assumption. For faithful bounded densities, the positive operator
\[
 H=\rho^{-1/2}(\rho^{1/2}\widetilde\nu\rho^{1/2})^{1/2}\rho^{-1/2}
\]
satisfies \(H\rho H=\widetilde\nu\). Finite spectral partitions of \(H\) have classical fidelities tending to \(\tau(\rho H)=F\); scalar Jensen gives \(D(p\Vert q)\ge-2\log\sum\sqrt{pq}\). This proves the needed fidelity bound. The measured variational formula follows from operator concavity of \(\log\) in one direction and finite spectral step approximations in the other.

Continuous spectrum at zero requires care. Choose a faithful bounded conditional comparison \(\nu_0\) bounded below on the supported corner, and replace
\[
 \rho_\eta=(1-\eta)\rho+\eta\nu_0,\quad
 \nu_\eta=(1-\eta)\nu+\eta\nu_0,\qquad\eta>0. \tag{4.4}
\]
Every positive \(\eta\) permits (4.1)–(4.3). The full and retained divergences converge separately to their finite original values. One direct verification uses uniform continuity of \(u\log u\) on a bounded interval, the bound
\(\log\nu_\eta\ge\log\nu+\log(1-\eta)\), and a fixed regularizer \(\log(\nu_\eta+\delta I)\) for the reverse limiting inequality. The additional \(\eta\nu_0\log\nu_\eta\) contribution is \(O(\eta|\log\eta|)\). Therefore their difference converges too.

Since \(\rho_\eta\to\rho\) in norm, its square roots converge in \(L^2\), uniformly for comparison with any normalized state. Consequently each positive slack admits an actual normal comparison with
\[
 F(\rho,\widetilde\nu_\eta)^2\ge e^{-b}-o_\eta(1). \tag{4.5}
\]
There is no claim that inverse powers converge, that removing a kernel creates a spectral gap, or that the comparison states have a normal limiting point. The positive-slack construction suffices.

## One common amplification and genuinely local corrections

Let the Alice replacement seed be \(T\in M_k(\mathcal N)\), \(k=|X|\), and write \(C=\sqrt T\), \(r_x=\tau(T_{xx})\). Use unnormalized matrix trace temporarily. In \(\mathcal P=M_k(\mathcal N)\), define
\[
 \chi_x=r_x^{-1/2}\sum_z e_{1z}\otimes C_{xz},\qquad
 \psi_{xy}^{\rm emb}=e_{11}\otimes\psi_{xy}. \tag{4.6}
\]
The \(\chi_x\) are unit vectors and
\(\chi_x\chi_{x'}^*=e_{11}\otimes T_{xx'}/\sqrt{r_xr_{x'}}\). The column index is the finite purifier.

For fixed \(y\), form
\[
 A_y=\sum_x e_{x1}\otimes\sqrt{q(x,y)}\psi_{xy},\quad
 B_y=\sum_{xz}e_{xz}\otimes\sqrt{\mu(y|x)}C_{xz}. \tag{4.7}
\]
Their left densities are the target and comparison \(y\) blocks. Their fidelity is \(\|A_y^*B_y\|_1\). Polar decomposition supplies \(U_y\) such that
\[
 \operatorname{Re}\tau(B_y^*A_yU_y)=\|A_y^*B_y\|_1.
\]
It acts by **right multiplication on purifier columns**, independently of the external coherent \(x\) row. Expanding this trace and applying Cauchy–Schwarz with the normalized comparison law \(r_x\mu(y|x)\) yields
\[
 e_A:=\mathbb E_q[1-|\langle\chi_x,\psi_{xy}^{\rm emb}U_y\rangle|^2]
 \le b_A+o(1). \tag{4.8}
\]
No equality of the target and comparison \(X\) marginals is used.

The separate Bob comparison bounds the **same target's** variation:
\[
 e_B:=\mathbb E_q P^2(d_{xy},d_y)\le b_B,
\quad d_{xy}=\psi_{xy}^*\psi_{xy},\quad
 d_y=\mathbb E_{x|y}d_{xy}. \tag{4.9}
\]
To see the information step, discard the protected copied question in the full divergence, use the conditional comparison form, and subtract the retained divergence. The remaining expression contains \(I(X:B|Y)\) plus a nonnegative question-law divergence. Then use \(P^2\le D\) in natural units. These finite-classical-record identities do not involve infinite entropies.

Write \(\chi_x=J_xu_x\), \(u_x=|\chi_x|\), and set
\[
 v_y=[U_y^*(e_{11}\otimes d_y)U_y]^{1/2}.
\]
For normalized densities \(a,b\), Hölder with exponents \(4,2,4\) gives
\[
 F(a,b)\le[\tau(\sqrt a\sqrt b)]^{1/2},\quad
 \|\sqrt a-\sqrt b\|_2^2\le2P(a,b)^2.
\]
Contract (4.8) to the right marginals and use (4.9) and the squared triangle inequality:
\[
 \mathbb E_q\|u_x-v_y\|_2^2\le4(b_A+b_B)+o(1). \tag{4.10}
\]

All finite families fit in one finite amplification. Partial polar factors have unitary completions after finite padding; an explicit completion for a partial isometry \(v\) is
\[
 \begin{pmatrix}v&I-vv^*\\I-v^*v&-v^*\end{pmatrix}.
\]
Left and right completions can use separate finite factors. The corrected fine effects are
\[
 A'_x=J_x^*(I\otimes A_x)J_x,\qquad
 B'_y=U_y^*(I\otimes B_y)U_y. \tag{4.11}
\]
They are complete POVMs; support-only versions put the complement into a default output. Trace cyclicity checks the Bob orientation. Every left effect commutes with every right effect on all input pairs. Normalizing the matrix trace rescales all vectors by the same square-root factor, leaving probabilities and estimates unchanged.

## Actual sampling, rare loss, and the fresh law

Apply the standard-form sampler of Appendix A to the finite families \(u_x,v_y\) and the transported fine POVMs. Its contract gives actual unconditional POVMs and, for the **same protocol**, a losing-event bound
\[
 \beta_q\le\alpha'+2\sqrt{\alpha'F_0}+F_0.
\]
The rare-event estimate in Appendix A gives \(F_0\le896(h^2+\overline D/h^2)+o(1)\), with \(\overline D\le2D_{\rm desc}+o(1)\). For small positive descriptor discrepancy choose \(h=D_{\rm desc}^{1/4}\); at zero discrepancy take positive \(h\downarrow0\), with inner accuracies chosen first at each \(h\). Equations (4.8)–(4.10) then give, with \(s=b_A+b_B\),
\[
 \sqrt{\beta_q}\le\sqrt\alpha+75s^{1/4}+o(1). \tag{4.12}
\]
This uses the sampler's actual good-vector and bad-branch estimates. A mean-TV sampler alone would not justify it.

For its all-input losing function \(f(x,y)\in[0,1]\),
\[
 |\sqrt{\mathbb E_qf}-\sqrt{\mathbb E_\mu f}|
 \le\|\sqrt q-\sqrt\mu\|_2\le\sqrt{D(q\Vert\mu)}. \tag{4.13}
\]
For \(t\le1\), (4.12)–(4.13) imply
\[
 \beta_\mu\le\alpha+152\sqrt\alpha\,t^{1/4}
                         +5776\sqrt t+o(1).
\]
The remaining regimes use the trivial upper bound one. Both coefficients are below \(65536\). Inner accuracies are taken to zero at a fixed finite family and fixed positive event probability. Every requested positive slack has actual complete POVMs and a fixed resource. This proves Theorem C.

The operational sampler used here is proved in Appendix A. Its first-success selection takes place in an amplified algebra, and its rare-event estimate applies to the actual unconditional output.

# The central construction: one target, two one-sided parents

## Exact presentation and charge

For every supported question pair of coordinate \(i\), choose an exact positive fractional rectangle partition
\[
 V_i(x,y,a,b)=\sum_lw_{i,xy,l}
                 {\bf1}_{R_{i,xy,l}}(a){\bf1}_{T_{i,xy,l}}(b),
 \quad w_{i,xy,l}\ge0. \tag{5.1}
\]
Equality includes losing cells. Let \(A_i(x,y),B_i(x,y)\ge1\) bound its maximum row and column loads, and put
\[
 a_i=\mathbb E_{\mu_i}A_i,\quad b_i=\mathbb E_{\mu_i}B_i,\quad
 \kappa_i=\tfrac12\log(a_ib_i). \tag{5.2}
\]
The parameter depends on the chosen presentation. Every finite Boolean mask has such a partition, for example singleton winning cells. Disjoint-block masks have unit loads and zero charge. A projection mask is disjoint-block by grouping rows with the same projected output; injectivity is unnecessary.

Consider an arbitrary finite-tracial joint strategy for an independent product of possibly different games. For a proper tested set \(D\), let \(p=\Pr(E_D)>0\), \(L=\log(1/p)\), and
\[
 \alpha_i(D)=\Pr\{\text{loss at }i\mid E_D\}.
 \tag{5.3}
\]
Fix tested questions \(c=(x_D,y_D)\). Product partitions give one exact mask with weights \(w_{c,l}\) and local load bounds \(A_c=\prod_D A_j(c_j)\), \(B_c=\prod_D B_j(c_j)\).

## One pure target with the original complete measured table

Coherently dilate the original full local measurements and retain every fine output on its own side. For live strings \(x,y\) and full fine outputs \(a,b\), write their residual standard-form vector as
\(\sqrt{P_a^{c_A,x}}\sigma\sqrt{Q_b^{c_B,y}}\).
Append three copies of a common label \(l\) on each target side and use amplitudes
\[
 \sqrt{\frac{\mu_J(x,y)w_{c,l}}{p_c}}\,
 {\bf1}_{R_{c,l}}(a_D){\bf1}_{T_{c,l}}(b_D)
 \sqrt{P_a^{c_A,x}}\sigma\sqrt{Q_b^{c_B,y}}. \tag{5.4}
\]
Here \(p_c=\Pr(E_D\mid c)>0\). Orthogonality of all fine-output and label registers plus (5.1) gives norm one and **exactly** the original conditional fine table.

This is a specified mathematical pure target. It is not claimed to arise from a new physically local filter on the original resource. Coherences outside the declared measured table can change. The same target must be used for both comparisons.

One own-label copy stays private in each residual workspace. External copies form the duplicated shared histories, with all such external copies omitted from each comparison parent. Fixing a label leaves a pure target; retaining a cross-created external copy in a reference would invalidate locality and is not done.

## Separate one-sided parents and positive operator-matrix domination

Alice's one-sided successful coefficients are
\[
 \sqrt{w_{c,l}/A_c}\,
 {\bf1}_{R_{c,l}}(a_D)\sqrt{P_a^{c_A,x}}.
\]
Their adjoint-products sum to at most identity. Adding the local coefficient
\[
 \left[I-\frac1{A_c}\sum_a
       \Big(\sum_lw_{c,l}{\bf1}_{R_{c,l}}(a_D)\Big)P_a^{c_A,x}\right]^{1/2}
\]
with a distinct failure sentinel completes a local isometry. Copying the sentinel into the external as well as private label records dephases success/failure when the external records are discarded. Bob has a **different** completion using \(B_c\) and \(T_{c,l}\). The two completions are not simultaneously applied. This prevents the erroneous coefficient \(w_l^2\).

There is a simpler normalization. Use each uncompleted positive one-sided seed and divide by its actual trace \(G_{A,c}\) or \(G_{B,c}\). Any normalized positive local seed is allowed by (3.2); its question marginal can differ from the target's. Thus no physical reference-preparation claim is required.

For the exact type-II check, at fixed \(y,l\) set
\[
 Z_{x,a}=\sqrt{\mu_J(x,y)w_{c,l}}\,
          {\bf1}_{R_{c,l}}(a_D)\sqrt{P_a^{c_A,x}}\sigma .
\]
The raw Alice parent is \(S_l=[Z_{x,a}Z_{x',a'}^*]\). The selected target parent is
\[
 T_l=[Z_{x,a}Q_{y,T_l}Z_{x',a'}^*],
 \quad Q_{y,T_l}=\sum_{b:b_D\in T_{c,l}}Q_b^{c_B,y}\le I.
\]
Therefore \(S_l-T_l\ge0\) by an operator-matrix congruence. No undefined partial trace over an infinite commutant or exchange of same-algebra factors occurs. Bob's calculation is in the opposite algebra.

These comparisons have the original conditional-question form: replace \(\sqrt{\mu_J(x,y)}\) in the Alice seed by \(\sqrt{\mu_{X,J}(x)}\), then attach the scalar conditional factors \(\sqrt{\mu_J(y|x)\mu_J(y|x')}\). Consequently
\[
 p_c\rho_{A,c}\le G_{A,c}\nu_{A,c},\qquad
 p_c\rho_{B,c}\le G_{B,c}\nu_{B,c}, \tag{5.5}
\]
with \(p_c\le G_{A,c}\le A_c\), \(p_c\le G_{B,c}\le B_c\).

The local-description proof in Section 4 needs one target and two conditional comparisons. It uses Alice's comparison for coherent alignment and Bob's for the same target's marginal variation. It never requires a common reference purification. This is the reason that separate comparison parents suffice.

## Exact entropy cancellation, tilted averaging, and allocation

For an ensemble \(\rho=\sum_lq_l\rho_l\), Donald's identity on both marginals gives
\[
 \begin{split}
 \sum_lq_l[D(\rho_l\Vert\nu)-D(\rho_l^K\Vert\nu^K)]
 &=D(\rho\Vert\nu)-D(\rho^K\Vert\nu^K)
       +I(l:R|K).
 \end{split} \tag{5.6}
\]
The private orthogonal label in \(K\) determines \(l\), so the last term is zero, including for question-correlated labels. Order domination in (5.5) then bounds the parent deficit by
\(\log(G_{A,c}/p_c)\) or \(\log(G_{B,c}/p_c)\).

Let \(Q_C(c)=\mu_D(c)p_c/p\), \(G_A=\mathbb E_{\mu_D}G_{A,c}\), and similarly \(G_B\). The exact change-of-measure identity is
\[
 \mathbb E_{Q_C}\log(G_{A,c}/p_c)
 =L+\log G_A
       -D\!\left(Q_C\middle\Vert
                  \frac{\mu_D(c)G_{A,c}}{G_A}\right)
 \le L+\log G_A. \tag{5.7}
\]
Zero-\(p_c\) branches have zero target weight. This is not an exchange of prior and posterior expectations. Product load bounds give
\[
 G_A\le\prod_{j\in D}a_j,\qquad
 G_B\le\prod_{j\in D}b_j. \tag{5.8}
\]

For completeness we spell out the ordered allocation, using the copied-register chain rule \cite[Lemma 2.24]{Jain}. Write \(R_i=\widehat X_i\widehat Y_i\). On Alice's side trace \(R_{>i}\), condition only on the classical exposed records \((\widehat Y_{<i},X_{>i})\), and retain the fixed records. Direct-sum relative entropy makes the expected coordinate deficit
\[
 D(\rho^{R_{\le i}K}\Vert\nu^{R_{\le i}K})
 -D(\rho^{R_{<i}K}\Vert\nu^{R_{<i}K}).
\]
Summing telescopes to the parent deficit. The restriction commutes with attaching the fresh \(i\)-th conditional-question amplitudes, so its comparison form is preserved. Bob uses the reverse order. Both target families are partitions of (5.4): their external histories carry the same \(c,l,Y_{<i},X_{>i}\), their residual spaces carry the complementary coherent questions and the original fine records.

Crucially the local-preparation theorem is applied to the **whole** \(x_i,y_i\)-indexed target with histories inside its output workspace. The history is not sampled independently beforehand.

The unconditional fresh question marginals \(q_i^{X_iY_i}\) satisfy
\[
 \sum_{i\notin D}d_i
 :=\sum_{i\notin D}D(q_i^{X_iY_i}\Vert\mu_i)\le L. \tag{5.9}
\]
Indeed event conditioning has density at most \(1/p\) relative to the full product referee law; classical relative entropy to a product dominates the sum of its coordinate marginal divergences.

Set \(t_i=b_{A,i}+b_{B,i}+d_i\). Equations (5.6)–(5.9) and Theorem C prove
\[
 \boxed{\sum_{i\notin D}t_i
 \le3L+\log(G_AG_B)
 \le3L+2\sum_{j\in D}\kappa_j,} \tag{5.10}
\]
with, for every positive accuracy, legal single-game witnesses of loss
\[
 \alpha_i(D)+K\big(\sqrt{\alpha_i(D)}\,t_i^{1/4}+\sqrt{t_i}\big)
       +\text{accuracy}. \tag{5.11}
\]
This proves the charged finite-tracial \(\mathrm{FR}(65536)\) condition at the stated exact fractional-partition scope.

## The parity challenge and why the question quantifier matters

Let \(X_i=Y_i\) be iid uniform bits and a sure common checked label be the parity of all live bits. The history \((l,Y_{<i},X_{>i})\) fixes the fresh bit, so
\(\sum_i\mathbb E_{\rm history}D(q_i^{XY|\rm history}\Vert\mu_i)=m\log2\)
despite \(p=1\). Charging this conditional divergence by \(L=0\) would be false.

Our \(d_i\) is unconditional and equals zero. Histories stay in the full target; both local kernels can generate the same parity from the equal fresh bit and pre-shared outside bits. Equivalently,
\[
 D(Q_i^{RXY}\Vert\mu_i Q_i^{R|X})
 =d_i+I(Y:R|X)\le d_i+b_{A,i},
\]
and symmetrically for Bob. No conditional-history law is silently replaced by \(\mu_i\). The standalone whole-workspace preparation makes a separate history race unnecessary.

# Scalar closure and amplification consequences

## Eliminate the representation before Lin

For \(K\ge1\), define
\[
 \Phi_K(e,a)=
 \left[\frac{\sqrt{a+4(e-a)_+/K}-\sqrt a}{2}\right]^4. \tag{6.1}
\]
Every legal extracted base strategy has loss at least
\(\epsilon_i=1-\omega_{\mathrm{co}}(G_i)\). Let the positive accuracy in (5.11) decrease to zero and solve the quadratic in \(t_i^{1/4}\). Equations (5.10)–(5.11) imply
\[
 \sum_{i\notin D}\Phi_K(\epsilon_i,\alpha_i(D))
 \le3\log(1/p_D)+\log(G_A(P,D)G_B(P,D)). \tag{6.2}
\]

The actual masses are finite positive linear table functionals. Explicitly,
\[
 G_{A,c}(P)=\sum_lw_{c,l}
 \sum_{x_J}\mu_{X,J}(x_J)
 \sum_{a:a_D\in R_{c,l}}P_A(a\mid c_A,x_J), \tag{6.3}
\]
and Bob is symmetric. These functionals are independent of the chosen finite-tracial representation. For each tested question \(c\), \(G_{A,c},G_{B,c}\ge p_c\); their prior-averaged masses \(G_A,G_B\) satisfy \(G_A,G_B\ge p_D>0\). It is these averaged masses that occur in (6.2).

Lin's Definition 3.1 and Theorem 3.2 \cite{LinTr} gives full finite-table closure of finite-tracial strategies in \(C_{qc}\). At a fixed \(D\) with target \(p_D>0\), the probabilities, conditional losses, and masses in (6.2) converge. The arguments of the logarithms stay bounded away from zero and \(\Phi_K\) is continuous. Thus (6.2) passes to arbitrary commuting strategies. No raw costs, vectors, algebras, or POVMs are asserted to converge. Finite tracial does not mean finite matrix.

Using (5.8) gives the scalar budget with \(3L+2\sum_D\kappa_j\). This closure is independent of the old resolvent/history proof. It still depends on the exact standalone sampler and Lin's theorem.

## Quadratic repetition and charged games

For an identical block game, (5.10) has zero presentation charge. Here is a complete all-finite-length proof of (A). First suppose a finite-tracial repeated strategy has all-wins probability
\(\theta>\exp(-\gamma\epsilon^2n)\), \(\gamma=2^{-75}\), and put \(L_\theta=\log(1/\theta)\).
Greedily test a coordinate whose conditional loss exceeds \(\epsilon/2\) while the remaining mean loss does so. Each addition raises log inverse event probability by more than \(\epsilon/2\), while every tested event contains all wins. Fewer than \(2L_\theta/\epsilon<n/2\) coordinates can be tested. At stopping, \(m\ge n/2\), \(p_D\ge\theta\), and mean remaining loss \(\alpha\le\epsilon/2\).

Mix the single-coordinate witnesses with a pre-shared uniform index. Cauchy–Schwarz and Jensen bound its loss by
\(\alpha+K[\sqrt\alpha(\mathbb Et_i)^{1/4}+\sqrt{\mathbb Et_i}]\)
at arbitrary positive slack. Now \(\mathbb Et_i\le3L_\theta/m<6\gamma\epsilon^2\). Its limiting loss divided by \(\epsilon\) is at most
\[
 \frac12+\frac K{\sqrt2}(6\gamma)^{1/4}
                 +K\sqrt{6\gamma}<0.665<1.
\]
A sufficiently small finite slack contradicts the base commuting gap. Zero gap or zero all-wins probability is trivial. We have therefore proved a uniform scalar all-wins bound for every finite-tracial table. Applying Lin's finite-table closure to that bound, and only then taking the arbitrary-commuting supremum, proves (A). No operational witnesses or raw \(t_i\) are passed through that limit.

For a common charge \(\kappa\), set \(t_0=1/(256K^4)=2^{-72}\). A live coordinate with conditional loss at most \(\epsilon/2\) has inverse deficit at least \(t_0\epsilon^2\). For this argument, test any live coordinate with conditional loss greater than \(\epsilon/2\) until none remains; do not stop merely when the mean is small. If \(L_\theta=\log(1/\theta)\), the tested set has size at most \(2L_\theta/\epsilon\) and total charge at most \(2\kappa L_\theta/\epsilon\). If the process stops with live coordinates, the scalar budget implies
\[
 t_0\epsilon^2(n-2L_\theta/\epsilon)
       \le(3+4\kappa/\epsilon)L_\theta,
\]
and hence
\[
 L_\theta\ge
 \frac{t_0\epsilon^2n}{3+4\kappa/\epsilon+2t_0\epsilon}
 \ge\frac{2^{-75}\epsilon^3n}{\epsilon+\kappa}.
\]
If all coordinates are exhausted, their tested losses already give \(L_\theta\ge n\epsilon/2\), which is stronger. Thus
\[
 \boxed{\omega_{\mathrm{co}}(G^{\otimes n})
 \le\exp[-2^{-75}\epsilon^3n/(\epsilon+\kappa)].} \tag{6.4}
\]
For zero gap the exponent is interpreted as zero, including when \(\kappa=0\).
For general masks, singleton rectangles give a general cubic-gap estimate. A row-star partition has one unit load and the other at most \(|A|\); a column-star partition reverses the roles. Hence one may always take
\[
 \kappa\le\tfrac12\log\min\{|A|,|B|\}. \tag{6.5}
\]
This refinement follows by choosing the smaller of the row-star and column-star presentations.

**The gap power is optimal within the full block class.** The original binary line game \(L_m\) of Kempe–Regev has only equality masks and endpoint singleton masks, all of which are disjoint-block. Definition 3.1 and Theorem 3.2 of \cite{KR} give matching classical and no-signalling values, so
\[
 1-\omega_{\mathrm{co}}(L_m)=\epsilon_m=\frac1{2m-1}.
\]
Theorem 4.4 of \cite{KR} gives a classical repeated lower bound \((1-O(m^{-2}))^n\) for \(n\ge m^2\). Thus an absolute constant \(C\) satisfies
\[
 \omega_{\mathrm{co}}(L_m^{\otimes n})
 \ge\omega(L_m^{\otimes n})
 \ge \exp[-C\epsilon_m^2n]\qquad(n\ge m^2)
\]
for all sufficiently large \(m\). A universal exponent \(f(\epsilon)\) with \(f(\epsilon_m)/\epsilon_m^2\to\infty\) would contradict this lower bound. The power two in (A) is therefore optimal for its full disjoint-block class, up to constants. This does not optimize \(2^{-75}\), establish priority, or show optimality for the narrower class of total projections: the endpoint predicates in this fixture are partial.

For the tensor statement, start with a finite tensor strategy and use a full matrix standard form. Every step above, including all sampler copies, stays a full finite matrix algebra; its left/right action is a genuine finite tensor resource. The greedy contradiction therefore uses \(\epsilon_*\), uniformly before the supremum. This does not assert equality of tensor and commuting values.

## Heterogeneous games and weighted thresholds

Let \(\epsilon_i=1-\omega_{\mathrm{co}}(G_i)\), assume
\(\kappa_i\le C_0\epsilon_i\), and put
\[
 S=\sum_i\epsilon_i^2,\qquad
 Z=\sum_i\epsilon_i{\bf1}\{\text{loss at }i\}.
\]
The following consequences hold:
\[
 \boxed{\omega_{\mathrm{co}}(\bigotimes_iG_i)
 \le\exp[-2^{-75}S/(1+C_0)],} \tag{6.6}
\]
\[
 \boxed{\Pr\{Z\le(1-r)S\}
 \le\exp[-2^{-85}r^5 S/(1+C_0)],
 \quad0<r\le1.} \tag{6.7}
\]
For blocks \(C_0=0\). The zero-\(S\) interpretation is the trivial upper bound one.

For clarity, the scalar deduction of (6.7) is included. Set \(M_D=3\log(1/p_D)+2\sum_D\kappa_i\). Apply the inverse deficit (6.1), cap the conditional loss by \(\alpha_i'=\min(\alpha_i,\epsilon_i)\), and use Hölder to obtain
\[
 S_D-A_D\le K[S_D^{3/4}M_D^{1/4}+\sqrt{S_DM_D}],
\quad S_D=\sum_{i\notin D}\epsilon_i^2,\ 
 A_D=\sum_{i\notin D}\epsilon_i\alpha_i(D).
\]
The cap is necessary for the Hölder step.

Independently include \(i\) in a random tested set with probability
\(u\epsilon_i/(1+u\epsilon_i)\), and condition its selected tests to succeed. Its normalization is
\[
 F(u)=\mathbb E\prod_i(1+u\epsilon_i)^{-{\bf1}\{\text{loss at }i\}},
\quad L(u)=-\log F(u).
\]
The posterior entropy identity gives \(\mathbb E\log(1/p_D)\le L(u)\), while
\(\mathbb ES_D\ge(1-u)S\) and
\(\mathbb E\sum_D\kappa_i\le C_0uS\).
Under the tilted outcome law \(T_u\),
\[
 \mathbb E_{T_u}Z\ge(1-u)S
 -K[S^{3/4}\overline M^{1/4}+\sqrt{S\overline M}],
\quad\overline M\le3L(u)+2C_0uS,
\]
\[
 L'(u)\ge\mathbb E_{T_u}Z/(1+u).
\]
Take \(\lambda=r^4/[2^{20}K^4(1+C_0)]\). Wherever \(0\le u\le\lambda\) and \(L(u)\le\lambda S\), the error is below \(rS/16\); thus
\(L'(u)\ge(1-r/4)S\). By monotonicity, either \(L(\lambda)\ge\lambda S\) or this derivative bound integrates throughout the interval. In both cases
\(L(\lambda)\ge(1-r/4)\lambda S\).
On \(Z\le(1-r)S\) the product defining \(F(\lambda)\) is at least \(e^{-\lambda(1-r)S}\). Therefore the event probability is at most \(e^{-r\lambda S/2}\), which is (6.7) for \(K=2^{16}\). Full tested sets contribute zero live mass; zero-probability tested events have zero posterior weight.

For (6.6), test a positive-gap coordinate whenever its conditional loss exceeds \(\epsilon_i/2\). Then \(\sum_D\epsilon_i\le2L_\theta\), \(\sum_D\epsilon_i^2\le2L_\theta\), and \(\sum_D\kappa_i\le2C_0L_\theta\). With \(t_0=1/(256K^4)=2^{-72}\), a conditional loss at most \(\epsilon_i/2\) forces \(\Phi_K\ge t_0\epsilon_i^2\). Hence
\(t_0(S-2L_\theta)\le(3+4C_0)L_\theta\), which implies (6.6). Exhausting every positive-gap coordinate gives the bound directly.

The intrinsic rate
\(\exp[-c\sum_i\epsilon_i^3/(\epsilon_i+\kappa_i)]\)
without a bounded ratio is still open. One must not multiply bounds for separate groups.

