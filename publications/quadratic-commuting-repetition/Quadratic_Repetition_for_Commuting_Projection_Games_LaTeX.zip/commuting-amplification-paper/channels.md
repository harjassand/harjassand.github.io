# Interactive noisy-channel verification: proof and exact scope

For finite density matrices, use the sandwiched divergence
\[
 D_\alpha(\rho\Vert\sigma)
 =\frac1{\alpha-1}\log\operatorname{Tr}
 [(\sigma^{(1-\alpha)/(2\alpha)}\rho
                 \sigma^{(1-\alpha)/(2\alpha)})^\alpha].
\]
Inverse powers are restricted to the comparison support; the divergence is \(+\infty\) when \(\operatorname{supp}\rho\not\subseteq\operatorname{supp}\sigma\). Trace distance below means \(\tfrac12\|\rho-\sigma\|_1\).
Define
\[
 I_\alpha(\mathcal N)
 =\sup_{\psi_{RQ}\ {\rm pure}}\inf_{\zeta_B}
 D_\alpha(({\rm id}_R\otimes\mathcal N)(\psi)
                         \Vert\psi_R\otimes\zeta_B). \tag{8.1}
\]
The unchanged-reference marginal is fixed. Some simulation papers reverse this orientation; that alternative is not substituted.

## Complete proof of Theorem B

The initial shared state is independent of the full referee question record and the laboratories initially receive only their respective local questions. Section 8.2 handles correlated initial resources with an additional source cost.

Gupta--Wilde \cite[Lemma 5, (5.16), (5.19)--(5.20)]{GW} gives
\[
 I_\alpha(\mathcal N)=\inf_\zeta
 D_\alpha(\mathcal N\Vert\mathcal R_\zeta),\quad
 \mathcal R_\zeta(Z)=\operatorname{Tr}(Z)\zeta.
\]
Wilde--Berta--Hirche--Kaur \cite[Proposition 41, (283)]{WBHK} gives, for arbitrary different input states and arbitrary reference memories,
\[
 D_\alpha(\mathcal N(\rho_{RQ})\Vert\sigma_R\otimes\zeta)
 \le D_\alpha(\rho_{RQ}\Vert\sigma_{RQ})
                  +D_\alpha(\mathcal N\Vert\mathcal R_\zeta).
 \tag{8.2}
\]
This amortization collapse is for a channel versus a replacer, not for two arbitrary channels.

Choose almost-minimizing replacers separately for each prescribed slot and fixed \(\alpha\). Compare the real interactive protocol with the same local protocol in which every cross-player channel is replaced by its fixed local discard-and-prepare map. Include all referee questions, outputs, memories, and both laboratories in the reference for (8.2). Initially the states agree. Between slots, the same local maps cannot increase divergence. At slot \(j\), (8.2) adds at most \(I_\alpha(\mathcal N_j)\) plus arbitrarily small slack. The final divergence is at most their sum, regardless of local feedback or transmission direction.

The all-replacer experiment is a legal zero-communication quantum strategy with acceptance \(q\le q_0\). Apply the same binary acceptance measurement to both final states. Binary data processing gives
\[
 D_\alpha(\operatorname{Ber}(p)\Vert\operatorname{Ber}(q))
 \ge\frac{\alpha}{\alpha-1}\log p-\log q.
\]
This proves (B), after removing finite slack. If \(q_0=0\), finite channel costs force \(p=0\); if \(q_0=1\), cap at one. The argument supplies no unrestricted infinite-algebra Rényi statement about communicating arbitrary-co resources.

## Source correlations, smoothing, and transcript errors

Let the actual normalized cq initial state be \(\rho_{UAB}\), where \(U\) is the full referee question record and \(A,B\) are the device resources before ordinary local question copies are delivered. For one question-independent resource \(\sigma_{AB}\), suppose
\[
 J_\alpha\ge D_\alpha(\rho_{UAB}\Vert
        \sum_u\mu_H(u)|u\rangle\langle u|\otimes\sigma_{AB}).
\]
The same telescope yields
\[
 p\le\inf_{\alpha>1}\exp\!\left\{
 \frac{\alpha-1}{\alpha}
 [\log q_0+J_\alpha+\sum_jI_\alpha(\mathcal N_j)]\right\}. \tag{8.3}
\]
Every term must use the **same** order. A normalized cq state within trace distance \(\eta\) of a state satisfying the displayed Rényi bound adds \(\eta\) once, after the whole protocol.

There is a different algebraic source interface. If the complete controlled acceptance effects obey
\[
 P_{\rm actual}\le e^hP_{\rm independent}+\eta
\]
by a certified hockey-stick/order defect, then the valid finite-order consequence is
\[
 p\le\eta+e^h
 \inf_{\alpha>1}
 e^{\frac{\alpha-1}{\alpha}(\log q_0+\sum_jI_\alpha(\mathcal N_j))}. \tag{8.4}
\]
This interface yields (8.4); moving \(h\) inside the Rényi factor is not justified by the normalized-smoothing argument. For example \(\rho=|0\rangle\langle0|\), \(\sigma=|+\rangle\langle+|\), multiplier two, has hockey-stick defect \((\sqrt5-1)/2\), but its nearest normalized state dominated by \(2\sigma\) is at trace distance \(1/\sqrt2\). These two smoothing notions are not equivalent. This example distinguishes the interfaces; it does not rule out every stronger inequality under additional assumptions.

If the referee tolerates a nonnegative integer \(r\) failed coordinates and an adversary can edit a nonnegative integer \(t\) coordinate answer records after the interaction and after seeing the transcript, while the referee retains its original questions, acceptance implies at most \(r+t\) original failures. Apply (B) or (8.3) to that original threshold event. For a threshold with \(\delta=\epsilon-(r+t)/n>0\), one may apply any available general-game threshold bound. The block bound below is proved here. For identical blocks use (6.7), with \(r_{\rm rel}=\delta/\epsilon\), giving the available rate \(2^{-85}\delta^5/\epsilon^3\). An actual perfect honest strategy remains accepted under \(t\) edits when the tolerance is at least \(t\); supremum-one completeness is preserved as a supremum. No noisy honest implementation is assumed.

## Capacity-rate consequence and exact channel assumptions

Suppose \(\omega_{\mathrm{co}}(H_n)\le e^{-gn}\). Channels come from a fixed finite family \(\mathcal M_l\), with prescribed slot counts \(m_l(n)/n\to\beta_l<\infty\), in any prescribed order/directions. Their environments are independent and inaccessible; no timing, routing, identity-selection, or classical control signal is free.

Finite-dimensional continuity \(I_\alpha\to C_E\) at order one implies exponential soundness if
\[
 \sum_l\beta_lC_E(\mathcal M_l)<g. \tag{8.5}
\]
Choose one fixed order sufficiently close to one with a strict margin and apply (B). For arbitrary \(n\)-dependent correlated sources, a bound on \(J_1/n\) alone is insufficient; require a fixed-order margin in (8.3), or a justified uniform/iid Rényi-regularity condition.

Noiseless classical \(c\)-bit and quantum \(q\)-qubit channels have costs \(c\log2\) and \(2q\log2\) at every order. Letting \(\alpha\to\infty\) recovers the factors \(2^c,4^q\). The noiseless factors also follow from transcript guessing and teleportation. Our finite-order theorem is stated for finite-dimensional protocols; it is not an assertion about arbitrary normal communicating maps on von Neumann algebras.

For arbitrary finite channels a direct maximum-order comparison uses
\[
 M(\mathcal N)=\min\{\operatorname{Tr}S:
              S\ge0,\ I_Q\otimes S\ge J_{\mathcal N}\}.
\]
Here \(J_{\mathcal N}=\sum_{r,s}|r\rangle\langle s|\otimes\mathcal N(|r\rangle\langle s|)\) is the unnormalized Choi matrix. CP order gives \(p\le q_0\prod_jM(\mathcal N_j)\), reference-uniformly. This is the known channel max-information/simulation quantity, not a new invariant.

# Concrete strict gain and matched coding comparator

For a \(d\)-dimensional erasure channel with survival \(s\),
\[
 \mathcal E_{s,d}(\rho)=s\rho\oplus(1-s)\operatorname{Tr}(\rho)|e\rangle\langle e|,
\]
the exact costs are, with \(u=(\alpha-1)/\alpha\),
\[
 I_\alpha(\mathcal E_{s,d})
 =u^{-1}\log[1-s+s d^{2u}],\quad
 C_E=2s\log d,\quad I_\infty=\log(1-s+sd^2). \tag{9.1}
\]
To verify the formula, compare to \(zI_d/d\oplus(1-z)|e\rangle\langle e|\). A pure input's successful-block power is bounded using its at most \(d\) Schmidt coefficients, with equality for a maximally entangled input. Twirling that input shows arbitrary replacers cannot improve it. Minimizing
\(a^\alpha z^{1-\alpha}+b^\alpha(1-z)^{1-\alpha}\),
\(a=sd^{2u},b=1-s\), gives \((a+b)^\alpha\). Thus both sides match. The same value at maximum order follows from CP domination of the erasure and surviving blocks.

There is a strict transfer for every certified exponent \(0<g\le1/4\). Allow one qubit-erasure slot per game coordinate with
\(s=3g/(8\log2)\). Order \(\alpha=4/3\) gives
\[
 p_n\le e^{-gn/64}, \tag{9.2}
\]
while both raw qubit counting and the optimum per-slot maximum-order cost are vacuous. Indeed \(I_{4/3}<15g/16\), whereas
\(\log(1+3s)>g\). This includes the conservative exponents of the present repetition results. For tiny \(g\) the required erasure rate is correspondingly extreme; no practical efficiency follows.

A completely solvable comparator makes the gain concrete. Let Alice receive a uniform \(n\)-bit string, Bob receive one fixed question, and require Bob to output that string. Its commuting zero-communication value is exactly \(2^{-n}\). Allow \(4n\) forward qubit-erasure slots with survival \(1/10\). Counting charges \(4\log4>\log2\); exact maximum-order domination charges \(4\log(13/10)>\log2\). Both fail. The finite-order bound gives
\[
 p_n\le e^{-E_*n},\qquad
 E_*=4D_{\rm bin}(1/8\Vert1/10)
      =0.01297370627\ldots>1/100. \tag{9.3}
\]
The maximizing \(u\) satisfies \(4^u=9/7\).

For even \(n\), an explicit randomized linear protocol achieves
\[
 \frac9{32(4n+1)}e^{-E_*n}
 \le p_{\rm construction}\le p_{\rm optimal}\le e^{-E_*n}. \tag{9.4}
\]
Pre-share \(4n\) EPR pairs and a uniform binary \(8n\times n\) matrix \(B\). Alice dense-codes consecutive pairs of \(BX\) into the EPR halves and sends them through the slots. Bob reads surviving pairs and samples uniformly from the affine solution space. With \(K=n/2\) surviving slots, the resulting square random binary matrix is invertible with probability at least \(9/32\). The binomial type probability is at least
\((4n+1)^{-1}e^{-4nD_{\rm bin}(1/8\Vert1/10)}\).
Multiplication proves (9.4).

Costs: \(4n\) transmitted qubits, \(4n\) EPR pairs, \(8n^2\) pre-shared random bits, \(O(n^2)\) encoding work and \(O(n^3)\) binary elimination work. There is no exponential codebook or unreported deterministic-code acquisition. The described decoder is a finite binary-elimination algorithm. The resource analysis assumes ideal dense coding and the specified memoryless erasures.

The exact channel-coding exponent agrees with Li--Yao \cite[Theorem 6]{LY}. This construction is a matched demonstration of the theorem's strength, not a new coding theorem. 

