# Quadratic Repetition for Commuting Projection Games and Noisy Quantum Communication

Harjas Sandhu, 7 November 2026.

Build the complete modular manuscript:
    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The standalone file supplied alongside this package also builds with latexmk
without any local input files. The bibliography and TikZ figure are embedded.
A normal TeX Live installation with amsart, Latin Modern, microtype, geometry,
TikZ, hyperref, enumitem and mathtools suffices. No BibTeX run is needed.

The Markdown files are editorial sources. The corresponding TeX files are
included, so Pandoc is not required to compile the paper. The manuscript
distinguishes the main reconstruction theorem from charged/heterogeneous
consequences and the finite-dimensional noisy-channel application. It does
not assert general arbitrary-predicate quadratic repetition, a finite-matrix
implementation for arbitrary commuting correlations, or an efficient
Hamiltonian/cryptographic compiler.
