# Global Readouts of Noisy Quantum Dynamics

Harjas Sandhu, The University of Queensland. Manuscript dated 8 November 2026.

This directory contains the complete modular LaTeX source. Both figures are
native TikZ drawings; no external graphics or bibliographic database is needed.

Build with a standard TeX Live installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The output is `main.pdf`. Alternatively, run `pdflatex main.tex` repeatedly until
references and the contents stabilize. Required packages are listed in
`main.tex`; the bibliography is included in `references.tex`.

The separately supplied `Global_Readouts_of_Noisy_Quantum_Dynamics.tex` is a
standalone version with all sections, diagrams and references embedded. It
builds independently of this directory.

The principal result is additive global-product-readout prediction for the
stated two-dimensional replacement-noise model. Full-output sampling requires
the additional cut certificate. The manuscript retains its conservation,
faithfulness, source, numerical precision and acquisition assumptions. It does
not claim a general two-dimensional sampler or practical quantum-computing
advantage.
