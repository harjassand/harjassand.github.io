# Magnetic Seed Amplification with Kinetic Recovery in Resistive Magnetohydrodynamics

Harjas Sandhu — The University of Queensland — 11 November 2026.

Build with TeX Live (AMS article, Latin Modern, microtype, mathtools, mathrsfs, booktabs, enumitem, TikZ and hyperref):

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

For the standalone source use its filename instead of main.tex. No shell escape, external figures, bibliography processor or data download is needed.

## Scope and relation to the companion

The main six-mode theorem amplifies a supplied oriented seed into an explicitly represented order-one magnetic field and recovers small total velocity, with calibrated viscosity, a paid prepared-pair error and one force for every positive magnetic diffusivity bounded above. A second theorem works with unknown viscosity and diffusivity but guarantees a magnetic observation rather than kinetic recovery. The near-guide theorem has a supplied nonzero flux and a growing mechanical force bank. These direct statements and proofs are retained.

Corollary 9.1 supersedes the former conditional common-control Theorem 9.1. It follows from Theorem 2.2 of the supplied companion, *Twelve-Mode Ensemble Control of Navier–Stokes and Resistive MHD*, by taking constant coefficients and zero magnetic mean. Its numerical parameter changes by only a fixed factor. Corollary 9.2 derives the H1 entrance needed before writing from that companion's actual eraser and waiting lemma; it is not inferred from an L2 endpoint alone.

Theorem 10.2 remains conditional. Appendix D states the additional physical implementation with arbitrary known smooth magnetic prefixes. The companion does not automatically prove those estimates. Its constant-mean writer is a different interface. The magnetic target is named B_tar to avoid confusion with the conserved constant H of the companion.

The duplicated conditional common-control proof, unused translation quadrature and old common-control schedule appendix are omitted. The original detailed guide-field calculation remains in Appendix E. The earlier versions remain preserved separately.

Both papers give costly periodic mathematical endpoints, not affordable hardware, arbitrary path tracking, sustained regulation or a matched engineering advantage. Numerical polynomial bounds and complete binary costs remain separate. The source acknowledgement and actual authorship are retained. No publication is implied by this package.
