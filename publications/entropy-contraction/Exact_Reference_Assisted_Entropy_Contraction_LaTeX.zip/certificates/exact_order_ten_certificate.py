"""One rational counterexample to an all-order Petz Renyi extension.

Only integer/Fraction arithmetic is used. This is one explicit counterexample,
not an optimization or a claim about orders in the data-processing interval.
"""
from fractions import Fraction as F
from pathlib import Path
import json


def main():
    r = F(3, 4)**10 / F(7, 10)**9 + F(1, 4)**10 / F(3, 10)**9
    lhs, rhs = r**8, F(10, 9)**27
    assert lhs > rhs
    result = {
        "status": "PASS",
        "arithmetic": "Exact integer and Fraction arithmetic",
        "scope": "One diagonal order-ten Petz Renyi example, outside the usual Petz data-processing range",
        "input_P": ["1", "0"],
        "input_Q": ["9/10", "1/10"],
        "output_P": ["3/4", "1/4"],
        "output_Q": ["7/10", "3/10"],
        "R": str(r),
        "positive_difference_R8_minus_10over9_27": str(lhs - rhs),
        "conclusion": "The divergence ratio exceeds 3/8",
    }
    Path(__file__).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "positive_difference_R8_minus_10over9_27"}, indent=2))


if __name__ == "__main__":
    main()
