# Exact Reference-Assisted Entropy Contraction from the Choi Matrix

Harjas Sandhu, The University of Queensland
Version 1.0, 14 November 2026

## Build

This archive contains the complete modular LaTeX source, editable bibliography,
vector figures defined in TikZ, a self-contained LaTeX file with its formatted
bibliography included, and small exact-arithmetic examples. There are no external
figure assets.

From this directory, run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

Alternatively run pdflatex main, bibtex main, then pdflatex main twice.
The standalone source can be compiled with pdflatex without BibTeX.
A standard TeX Live installation with AMS, Latin Modern, geometry, TikZ,
hyperref, cleveref, microtype, booktabs, tabularx and needspace suffices.

The checked manuscript has 39 pages. No numerical optimizer is required to build
or understand the analytic proofs.

## Exact examples

The certificates directory contains four Python scripts and their JSON results.
Run each exact_*_certificate.py with Python 3. The fixed-reference and
depolarizing scripts additionally use SymPy; the fixed-reference script imports
the interval-arithmetic routines in exact_triangle_certificate.py.
The scripts check two finite ternary-channel witnesses, one rational qubit
depolarizing Gram calculation, and an order-ten counterexample.
They are reproducible finite checks, not a formal verification of the general
theorems. No floating-point optimizer or SDP solver is used for these checks.

## Mathematical scope

The exact Choi program computes the complete equal-reference,
reference-subtracted, and explicitly conditional-information coefficients.
Ordinary quantum mutual information is a different optimization: an exact
formula is proved for qubit depolarization and bounds are given in higher
dimension.

The modular Petz theorem assumes a nonaffine operator-convex generator with
finite endpoint value and recession slope. Umegaki entropy has its own proof.
The Petz Renyi extension holds for each fixed order strictly between zero and
one. The Chernoff argument is locally uniform in the order at each fixed faithful
state. Generalized information means the explicit difference in equation (7.2).
No optimized/sandwiched Renyi conditional information or all-order extension is
claimed.

The results concern finite supplied channel descriptions. Exact evaluation is
distinct from stable experimental acquisition, efficient evaluation in physical
qubit count, physical simulation, recovery, or communication capacity.
The manuscript states the support conditions and boundary limitations in full.

## Licence and citation

The preprint and accompanying original source material are made available under
Creative Commons Attribution 4.0 International:
https://creativecommons.org/licenses/by/4.0/

The bibliography preserves attribution to the mathematical foundations.
Use the version DOI displayed on the public Zenodo record when citing this
release. The manuscript contains its authorship and AI-use acknowledgement.
