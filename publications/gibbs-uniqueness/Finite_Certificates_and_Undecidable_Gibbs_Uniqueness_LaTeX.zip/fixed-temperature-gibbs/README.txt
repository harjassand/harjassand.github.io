Finite Certificates and Undecidable Gibbs Uniqueness

Main file: main.tex

Build the modular project with:
    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

Alternatively run pdflatex, bibtex, pdflatex, pdflatex on main.tex.
The included main.bbl also permits two pdflatex runs without regenerating
bibliography data. The references.bib file retains DOI and primary-source
URL metadata, including the exact arXiv versions specified in the text.

The figures are native TikZ drawings; no external image assets are needed.
Dependencies are standard TeX Live packages listed in the main preamble.

The separately supplied single-file .tex embeds all sections and the
bibliography. It needs two pdflatex runs and no BibTeX run.

Source guide:
    overview.tex       One-page conceptual overview
    introduction.tex   Main construction, refinement and consequences
    construction.tex   Worked cancellation example and physical table
    selection.tex      Geometric explanation and quantitative proof
    acknowledgements.tex  Acknowledgements and AI-use disclosure
    main.tex           Byline and contact details
