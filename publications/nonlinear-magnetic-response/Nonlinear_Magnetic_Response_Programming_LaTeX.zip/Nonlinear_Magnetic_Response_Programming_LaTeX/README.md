# Programming Nonlinear Magnetic Response with Twelve Mechanical Modes

Harjas Sandhu, The University of Queensland. Review version, 12 November 2026.

## Build

From this directory run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The project uses standard TeX Live packages: AMS classes and mathematics,
Latin Modern, microtype, geometry, booktabs, array, enumitem, TikZ and hyperref.
The bibliography is included as `bibliography.tex`; no BibTeX download is
required. The mechanism diagram is native TikZ in the source. All technical
supplements are the article's appendices A–G and build into the same PDF.

## Exact scope

The main theorem programs the endpoint
`(U(x,H/M), H+Z(x,H/M))` of full resistive/viscous 3D MHD on the unit torus.
The complete finite Fourier-polynomial targets have even/odd total degree,
respectively, solenoidal mean-zero coefficient fields, and a paid weighted
coefficient-sum bound. Degree and support are variable input. The same
open-loop force uses only twelve fixed momentum modes and is uniform over
the bounded unknown H1 preparation, independent positive spatially constant
Lipschitz diffusivity histories, the stated absolute L∞-time L2-space
disturbances, and every energy-admissible weak realization.

Costs are polynomial in the theorem's numerical inverse parameters and full
description length, with exponent independent of target degree. This is not
polynomial time in binary input length alone, an affordable implementation,
a hardware demonstration or an autonomous fault-tolerant processor. No
unknown flux or coefficient is measured. The seed-preparation paper's
magnetic-channel Theorem 10.2 remains conditional on its own additional
hypotheses.

## Mathematical organization

- Main theorem and stable eleven-register arithmetic.
- Complete retained linear assembly, smooth-memory and physical gate/heat
  foundation, with its original stronger degree-four force statement.
- Actual directional filters, regularized restore, three-row decoder and
  whole-register cubic operations.
- Dyadic whole-space velocity amplifier, with actual forward-time controls
  and a common accumulated error metric.
- One collinear readout batch, complete high-output clearing, internal
  resistivity normalization and arbitrary-mode perturbation estimates.
- Noncircular parameter choices, exact clock, all-weak transfer and a
  terminating universal resource-majorant construction.
- Appendices with estimates, exact imports and complete new technical proofs.

## Finite checking scripts

The `checks/` directory contains the finite exact algebra checks cited by the
article. Run each with Python 3. The quadratic gate script additionally uses
SymPy; the arithmetic and readout-polarization scripts use the standard
library. JSON outputs state their scopes. These checks do not simulate MHD,
execute the full compiler or establish infinite-dimensional estimates by
sampling. The article's proofs establish those estimates.

The huge fixed rational shear-family precomputation is specified and paid
mathematically through the cited foundation. It is not claimed to have been
executed as part of preparing this manuscript.
