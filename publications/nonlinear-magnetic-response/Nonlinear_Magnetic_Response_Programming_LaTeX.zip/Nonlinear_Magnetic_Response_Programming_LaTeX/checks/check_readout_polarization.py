#!/usr/bin/env python3
"""Exact finite checks of readout certificates, not a PDE simulation."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json


def dot(a, b):
    return sum((x * y for x, y in zip(a, b)), F(0))


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def scale(c, a):
    return tuple(c * x for x in a)


def proj(v, m):
    return add(v, scale(-dot(v, m) / dot(m, m), m))


def gc_mul(z, w):
    return (z[0] * w[0] - z[1] * w[1],
            z[0] * w[1] + z[1] * w[0])


count = 0
for N in range(1, 5):
    L = 2 * N + 1
    ell = (F(1), F(L), F(L * L))
    Q = 6 * N * N + 7
    for mi in product(range(-N, N + 1), repeat=3):
        if mi == (0, 0, 0):
            continue
        m = tuple(map(F, mi))
        assert dot(m, ell) != 0
        q = proj(m, ell)
        assert dot(q, q) > 0
        a = scale(1 / dot(q, q), q)
        assert dot(a, m) == 1 and dot(a, ell) == 0
        for n in (1, 2, 7):
            k = scale(F(Q * n), ell)
            l = add(m, scale(-1, k))
            Delta = 2 * F(Q * n) * dot(m, ell) - dot(m, m)
            assert abs(Delta) >= Q * n
            for j in range(3):
                ej = tuple(F(int(i == j)) for i in range(3))
                d = proj(ej, m)
                beta = -F(Q * n) * dot(m, m) * dot(d, ell) / Delta
                b = add(add(d, scale(-beta, a)),
                        scale(2 * beta / dot(m, m), m))
                assert dot(a, k) == 0 and dot(b, l) == 0
                cert = proj(add(scale(dot(a, m), b),
                                scale(dot(b, m), a)), m)
                assert cert == d
                # The common-direction derivative identity also permits
                # negative tags and arbitrary rational transverse vectors.
                for nt in (-3, -1, 2):
                    ot = (F(2), F(-1), F(3))
                    kt = add(scale(F(Q * nt), ell), ot)
                    # l has tag -n and offset m.
                    rhs = dot(b, add(ot, scale(F(nt, n), m)))
                    assert dot(b, kt) == rhs
                count += 1

# Exact complex normalization.  kappa is factored out symbolically; choosing
# kappa=1 leaves all remaining arithmetic rational.  The identities checked
# here are i*(-i)=1, the heat denominator S*rho, and real quadratures.
phase_count = 0
for Q in (5, 11):
    sigma, rho, a0 = F(1, 17), F(2, 3), F(13)
    for h, C, D, S in product((F(0), F(-2, 5), F(3, 7)),
                              (F(0), F(2, 3)),
                              (F(-4, 7), F(1, 5)),
                              (F(23), F(101))):
        r = (C / 2, -D / 2)
        normalizer = a0 * S / (F(Q * Q) * sigma * sigma)
        B = gc_mul((F(0), -normalizer), r)
        A = rho * h / a0
        out = gc_mul((F(0), F(Q * Q) * sigma * sigma * A / (rho * S)), B)
        assert out == (h * C / 2, -h * D / 2)
        # Real second packet is proportional to C sin - D cos.
        assert B == (-normalizer * D / 2, -normalizer * C / 2)
        phase_count += 1

report = {
    "status": "passed",
    "scope": "exact finite rational polarization, derivative and phase certificates; no PDE or infinite-dimensional validation",
    "polarization_cases": count,
    "phase_cases": phase_count,
    "tested_N": [1, 2, 3, 4],
    "tested_tags": [1, 2, 7],
}
out = Path(__file__).with_name("readout_polarization_check.json")
out.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
