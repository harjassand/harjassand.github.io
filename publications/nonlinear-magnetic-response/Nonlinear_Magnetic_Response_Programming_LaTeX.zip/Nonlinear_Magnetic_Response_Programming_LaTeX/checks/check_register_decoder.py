#!/usr/bin/env python3
"""Exact finite Fourier checks of register routing and three-row decoding.

Selectors/averages below are mathematical comparison operators, not controls.
This is not a PDE simulation or a verification of the resource theorem.
"""
from pathlib import Path
from fractions import Fraction as F
import importlib.util
import json
import sys

base = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "linear_fourier_check", base/"check_five_gate_algebra.py")
f = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = f
spec.loader.exec_module(f)

def wave(j, freq, axis):
    return (f.sin if j % 2 == 0 else f.cos)(f.axis((j//2+1)*freq, axis))

def primitive(j, freq, axis):
    n = (j//2+1)*freq
    return (f.cos(f.axis(n, axis), -F(1, n)) if j % 2 == 0
            else f.sin(f.axis(n, axis), F(1, n)))

J = 4
s1, s2, s3 = 1000003, 10007, 101
A = [
    [f.sin((0, 1, 0), F(1, 3)), f.cos((1, 0, 0), F(1, 5)),
     f.sin((1, 0, 1), F(1, 7)), f.cos((1, 1, 0), F(1, 23))],
    [f.cos((0, 0, 1), F(1, 2)), f.sin((1, 1, 0), F(1, 11)),
     f.cos((0, 1, 0), F(1, 13)), f.sin((0, 1, 1), F(1, 29))],
    [f.sin((0, 1, 0), 2), f.cos((0, 1, 1), F(1, 17)),
     f.sin((1, 0, 0), F(1, 19)), f.cos((1, 0, 1), F(1, 31))],
]
phi1 = f.scale(f.add(*(f.product(f.add(A[0][j], primitive(j, s2, 2)),
                                    wave(j, s1, 1)) for j in range(J))), 2)
phi2 = f.scale(f.add(*(f.product(f.add(A[1][j], primitive(j, s3, 0)),
                                    wave(j, s2, 2)) for j in range(J))), 2)
phi3 = f.scale(f.add(*(f.product(A[2][j], wave(j, s3, 0)) for j in range(J))), 2)
stages = []
for j in range(J):
    B = [wave(j, s1, 1), {}, {}]
    B = f.selector(f.gate(0, phi1, B), s1//2)
    E1 = f.vadd(f.curl_component(0, A[0][j]), [{}, wave(j, s2, 2), {}])
    assert B == E1, (j, 1)
    B = f.selector(f.gate(1, phi2, B), s2//2)
    E2 = f.vadd(f.curl_component(0, A[0][j]), f.curl_component(1, A[1][j]),
               [{}, {}, wave(j, s3, 0)])
    assert B == E2, (j, 2)
    B = f.selector(f.gate(2, phi3, B), s3//2)
    target = f.vadd(*(f.curl_component(i, A[i][j]) for i in range(3)))
    assert B == target, (j, 3)
    stages.append(dict(code_basis=j, stages_checked=3))
for h in range(3):
    H = [{f.ORIGIN: f.QI(F(1))} if i == h else {} for i in range(3)]
    B = H
    for i, phi, cutoff in ((0, phi1, s1//2), (1, phi2, s2//2), (2, phi3, s3//2)):
        B = f.selector(f.gate(i, phi, B), cutoff)
        assert B == H, ("mean", h, i)

def average(vector, direction):
    return [{k: v for k, v in row.items() if k[direction] == 0}
            for row in vector]

C = [[F(1), F(1), F(0), F(0)],
     [F(0), F(0), F(1, 2), F(-1, 2)]]
Phi = f.scale(f.add(*(f.scale(f.product(primitive(l, 3, 2), wave(j, 1, 1)),
                                   C[l][j])
                      for l in range(len(C)) for j in range(J))), 2)
for j in range(J):
    B = [wave(j, 1, 1), {}, {}]
    B = average(f.gate(0, Phi, average(average(B, 2), 0)), 1)
    target = [{}, f.add(*(f.scale(wave(l, 3, 2), C[l][j])
                          for l in range(len(C)))), {}]
    assert B == target, ("router", j)
for h in range(3):
    H = [{f.ORIGIN: f.QI(F(1))} if i == h else {} for i in range(3)]
    B = average(f.gate(0, Phi, average(average(H, 2), 0)), 1)
    assert B == H

result = {
    "scope": "finite exact rational Fourier identities; no PDE simulation",
    "three_row_decoder": {"unknown_coefficients": J, "row_gates": 3,
                           "ideal_selectors": 3, "mean_basis_checked": 3,
                           "cases": stages, "status": "passed"},
    "unequal_frequency_router": {"input_coefficients": J,
                                "output_coefficients": len(C),
                                "mean_basis_checked": 3, "status": "passed"},
}
Path(__file__).with_name("check_register_decoder.json").write_text(
    json.dumps(result, indent=2)+"\n")
print(json.dumps(result, sort_keys=True))
