#!/usr/bin/env python3
"""Exact sparse-Fourier examples of the five-gate identity; no PDE simulation.

Only the Python standard library is used. Normalized differentiation is ik.
The cutoff below is an IDEALIZED algebraic selector, not a physical actuator.
The general identity is proved in the manuscript, independently of this code.
"""
from dataclasses import dataclass
from fractions import Fraction as F
import json


@dataclass(frozen=True)
class QI:
    r: F = F(0)
    i: F = F(0)

    def __add__(self, other):
        if not isinstance(other, QI): other = QI(F(other))
        return QI(self.r + other.r, self.i + other.i)

    __radd__ = __add__

    def __neg__(self): return QI(-self.r, -self.i)

    def __sub__(self, other): return self + (-other)

    def __mul__(self, other):
        if not isinstance(other, QI): other = QI(F(other))
        return QI(self.r * other.r - self.i * other.i,
                  self.r * other.i + self.i * other.r)

    __rmul__ = __mul__

    def __bool__(self): return bool(self.r or self.i)


I = QI(F(0), F(1))
ZERO = QI()
ORIGIN = (0, 0, 0)


def add(*fields):
    out = {}
    for field in fields:
        for k, value in field.items(): out[k] = out.get(k, ZERO) + value
    return {k: v for k, v in out.items() if v}


def scale(field, value):
    return {k: v * value for k, v in field.items() if v * value}


def product(a, b):
    out = {}
    for k, v in a.items():
        for l, w in b.items():
            n = tuple(x + y for x, y in zip(k, l))
            out[n] = out.get(n, ZERO) + v * w
    return {k: v for k, v in out.items() if v}


def cos(k, coefficient=F(1)):
    return {k: QI(F(coefficient) / 2), tuple(-x for x in k): QI(F(coefficient) / 2)}


def sin(k, coefficient=F(1)):
    return {k: QI(F(0), -F(coefficient) / 2),
            tuple(-x for x in k): QI(F(0), F(coefficient) / 2)}


def axis(k, direction):
    return tuple(k if i == direction else 0 for i in range(3))


def curl_component(i, scalar):
    result = [{}, {}, {}]
    for k, value in scalar.items():
        vector = ((0, k[2], -k[1]), (-k[2], 0, k[0]), (k[1], -k[0], 0))[i]
        for j in range(3):
            if vector[j]: result[j][k] = I * value * vector[j]
    return result


def vadd(*vectors):
    return [add(*(v[j] for v in vectors)) for j in range(3)]


def gate(i, phi, magnetic):
    return vadd(magnetic, curl_component(i, product(phi, magnetic[i])))


def selector(vector, cutoff):
    return [{k: v for k, v in row.items() if max(map(abs, k)) <= cutoff} for row in vector]


def run(gamma, label):
    q1, q2, q3 = 1000003, 10007, 101
    pilot1, pilot2 = sin(axis(q1, 2)), sin(axis(q1, 1))
    w2 = [sin(axis(q2, 2)), cos(axis(q2, 2)), sin(axis(2 * q2, 2))]
    w3 = [sin(axis(q3, 0)), cos(axis(q3, 0)), sin(axis(2 * q3, 0))]
    chi2 = [cos(axis(q2, 2), -F(1, q2)), sin(axis(q2, 2), F(1, q2)),
            cos(axis(2 * q2, 2), -F(1, 2 * q2))]
    chi3 = [cos(axis(q3, 0), -F(1, q3)), sin(axis(q3, 0), F(1, q3)),
            cos(axis(2 * q3, 0), -F(1, 2 * q3))]
    a1 = [add(gamma[0][j], chi2[j]) for j in range(3)]
    a2 = [add(gamma[1][j], chi3[j]) for j in range(3)]
    phi1 = add(a1[0], scale(product(a1[1], pilot1), 2), scale(product(a1[2], pilot2), 2))
    phi2 = scale(add(*(product(a2[j], w2[j]) for j in range(3))), 2)
    phi3 = scale(add(*(product(gamma[2][j], w3[j]) for j in range(3))), 2)
    support_counts = []
    for col in range(3):
        h = [{ORIGIN: QI(F(1))} if j == col else {} for j in range(3)]
        magnetic = gate(1, cos(axis(q1, 2), F(1, q1)), h)
        magnetic = gate(2, cos(axis(q1, 1), -F(1, q1)), magnetic)
        magnetic = gate(0, phi1, magnetic)
        support_counts.append(len(set().union(*(set(v) for v in magnetic))))
        magnetic = selector(magnetic, q1 // 2)
        expected1 = vadd(h, curl_component(0, gamma[0][col]), [{}, w2[col], {}])
        assert magnetic == expected1, (label, col, 'first row')
        magnetic = gate(1, phi2, magnetic)
        magnetic = selector(magnetic, q2 // 2)
        expected2 = vadd(h, curl_component(0, gamma[0][col]), curl_component(1, gamma[1][col]), [{}, {}, w3[col]])
        assert magnetic == expected2, (label, col, 'second row')
        magnetic = gate(2, phi3, magnetic)
        magnetic = selector(magnetic, q3 // 2)
        target = vadd(h, *(curl_component(i, gamma[i][col]) for i in range(3)))
        assert magnetic == target, (label, col, 'target')
        divergence = add(*( {k: I * v * k[j] for k, v in row.items()} for j, row in enumerate(target)))
        assert not divergence
    return dict(example=label, columns_checked=3, gates=5, selectors=3,
                frequencies=[q1, q2, q3], pre_first_filter_support_counts=support_counts,
                status='exact rational Fourier identities passed')


def main():
    singular = [[{} for _ in range(3)] for _ in range(3)]
    singular[2][0] = sin((0, 1, 0), 2)
    mixed = [[sin((0, 1, 0), F(1, 3)), cos((1, 0, 0), F(1, 5)), sin((1, 0, 1), F(1, 7))],
             [cos((0, 0, 1), F(1, 2)), sin((1, 1, 0), F(1, 11)), cos((0, 1, 0), F(1, 13))],
             [sin((0, 1, 0), 2), cos((0, 1, 1), F(1, 17)), sin((1, 0, 0), F(1, 19))]]
    print(json.dumps([run(singular, 'singular noncommuting target'),
                      run(mixed, 'all nine potential entries')], indent=2))


if __name__ == '__main__':
    main()
