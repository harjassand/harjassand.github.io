"""Exact symbolic check of the quadratic phase averages used in the proof.

This checks finite differential identities, not the coupled compiler theorem.
"""
import json
from pathlib import Path
import sympy as s

x, y, z, th = s.symbols("x y z th", real=True)
K = s.symbols("K", positive=True)
phi = s.Function("phi")(x, y, z)
B = s.Matrix([s.Function(f"B{j}")(x, y, z) for j in (1, 2, 3)])
sn, cs = s.sin(th), s.cos(th)
U = s.Matrix([phi * cs + s.diff(phi, z) * sn / K,
              0, -s.diff(phi, x) * sn / K])
V = s.Matrix([0, sn, 0])

def deriv(f, j):
    return s.diff(f, (x, y, z)[j]) + (K*s.diff(f, th) if j == 2 else 0)

def direction(a, b):
    return s.Matrix([sum(a[j]*deriv(b[i], j) for j in range(3))
                     for i in range(3)])

def induction(a, b):
    return direction(b, a)-direction(a, b)

def avg(expr):
    expr = s.expand(expr)
    return s.simplify(s.integrate(expr, (th, 0, 2*s.pi))/(2*s.pi))

UU = induction(U, induction(U, B)).applyfunc(avg)
VV = induction(V, induction(V, B)).applyfunc(avg)
VU = induction(V, induction(U, B)).applyfunc(avg)
target = s.Matrix([s.diff(phi*B[2], y), -s.diff(phi*B[2], x), 0])*K/2
UU_K_coefficients = [s.simplify(s.expand(f).coeff(K, 1)) for f in UU]
VU_residual = (VU-target).applyfunc(s.simplify)
VV_residual = (VV-B.diff(y, 2)/2).applyfunc(s.simplify)
checks = {
    "U_U_no_positive_K_power": all(not any(term.as_powers_dict().get(K, 0) > 0
          for term in s.Add.make_args(s.expand(f))) for f in UU),
    "V_V_exact_half_yy": VV_residual == s.zeros(3, 1),
    "V_U_target_remainder_no_positive_K_power": all(not any(
          term.as_powers_dict().get(K, 0) > 0
          for term in s.Add.make_args(s.expand(f))) for f in VU_residual),
    "U_U_K_coefficient_zero": all(f == 0 for f in UU_K_coefficients),
}
assert all(checks.values()), checks
out = {
    "scope": "finite symbolic phase-average identities only",
    "checks": checks,
    "UU_average": [str(f) for f in UU],
    "VV_average": [str(f) for f in VV],
    "VU_minus_K_over_two_curl": [str(f) for f in VU_residual],
}
Path(__file__).with_name("gate_quadratic_check.json").write_text(
    json.dumps(out, indent=2)+"\n")
print(json.dumps(checks, sort_keys=True))
