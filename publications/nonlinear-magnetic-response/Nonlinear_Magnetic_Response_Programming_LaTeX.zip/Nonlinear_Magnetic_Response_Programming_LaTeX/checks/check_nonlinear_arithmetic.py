#!/usr/bin/env python3
"""Exact finite algebra checks; not an implementation of the PDE compiler.

Run with Python 3, standard library only. Output is reproducible JSON.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json


def add(a, b):
    c = dict(a)
    for k, v in b.items():
        c[k] = c.get(k, F(0)) + v
        if not c[k]:
            del c[k]
    return c


def shift(a, j, n=1):
    c = {}
    for alpha, value in a.items():
        beta = list(alpha)
        beta[j] += n
        c[tuple(beta)] = value
    return c


def mass(a):
    return sum(map(abs, a.values()), F(0))


def horner_sector(coeff, parity, degree):
    # Three work registers, a permanent source h^parity, and one output.
    out = {}
    assignments = 0
    injections = F(0)
    n = degree // 2
    for i in range(n, -1, -1):
        middle = {}
        for j in range(n, -1, -1):
            inner = {}
            for k in range(n, -1, -1):
                alpha = tuple(2 * v + p for v, p in zip((i, j, k), parity))
                c = coeff.get(alpha, F(0))
                inner = shift(inner, 2, 2)
                if c:
                    inner = add(inner, {parity: c})
                    injections += abs(c)
                assignments += 1
            middle = add(shift(middle, 1, 2), inner)
            inner = {}  # Transfer-and-clear is a single logical assignment.
            assignments += 1
        out = add(shift(out, 0, 2), middle)
        middle = {}
        assignments += 1
    return out, assignments, injections


def odd_horner(coeff, degree):
    total, count, injected = {}, 0, F(0)
    for parity in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1)]:
        sector = {a: c for a, c in coeff.items()
                  if tuple(x % 2 for x in a) == parity}
        got, n, m = horner_sector(sector, parity, degree)
        total = add(total, got)
        count += n + 1
        injected += m
    assert total == coeff
    assert injected == mass(coeff)
    return count


def main():
    checked = []
    for degree in range(1, 11):
        u, z = {}, {}
        for alpha in product(range(degree + 1), repeat=3):
            if sum(alpha) > degree:
                continue
            c = F((-1) ** (alpha[0] + alpha[2]) * (1 + alpha[1]),
                  7 + 2 * alpha[0] + 3 * alpha[1] + 5 * alpha[2])
            (u if sum(alpha) % 2 == 0 else z)[alpha] = c
        r = [{}, {}, {}]
        for alpha, value in u.items():
            d = sum(alpha)
            if not d:
                continue
            for j in range(3):
                if alpha[j]:
                    beta = list(alpha)
                    beta[j] -= 1
                    r[j] = add(r[j], {tuple(beta): value * F(alpha[j], d)})
        rebuilt = {(0, 0, 0): u[(0, 0, 0)]}
        for j in range(3):
            rebuilt = add(rebuilt, shift(r[j], j))
        assert rebuilt == u
        assert sum(map(mass, r), F(0)) <= mass(u) - abs(u[(0, 0, 0)])
        counts = [odd_horner(poly, degree) for poly in [z] + r]
        assert sum(counts) <= 128 * (degree + 1) ** 3
        checked.append({'degree': degree, 'terms': len(u) + len(z),
                        'assignments': sum(counts)})
    # Worked example: scalar coefficients in the e1*sin(2pi*x2) component.
    u = {(2, 0, 0): F(1, 32), (0, 1, 1): F(1, 32)}
    r = [{(1, 0, 0): F(1, 32)}, {(0, 0, 1): F(1, 64)},
         {(0, 1, 0): F(1, 64)}]
    assert add(add(shift(r[0], 0), shift(r[1], 1)), shift(r[2], 2)) == u
    assert F(3 * 8, 32) == F(3, 4)
    result = {'status': 'PASS', 'scope': 'exact finite polynomial algebra only',
              'degrees_checked': checked, 'worked_example_mass': '3/4',
              'does_not_test': 'PDE evolution, compiler implementation or universal estimates'}
    target = Path(__file__).with_suffix('.json')
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
