"""Exact finite fixtures only; not an implementation or validation of the full compiler."""
from fractions import Fraction as F
from math import factorial, prod
import json
from pathlib import Path

# A one-species fixture includes open, high-order, null and parallel labels.
R=[(0,1,F(1,2)),(1,0,F(1,3)),(2,3,F(1,4)),(3,2,F(1,5)),(2,2,F(1,6)),(2,2,F(1,7))]
U=8; K=F(5); Q=F(97); theta=1/Q; eta=F(1,1000)
names=['A']; payload=[1]; weights=[F(1)]; channels=[]; pending={}
def species(name,p,w):
 names.append(name);payload.append(p);weights.append(w);return len(names)-1
def complex_(*ids):
 d={}
 for i in ids:d[i]=d.get(i,0)+1
 return d
def channel(a,b,k,kind,r=None):channels.append((a,b,k,kind,r))
def pair(a,b,kf,kb,kind):
 channel(a,b,kf,kind);channel(b,a,kb,kind)
source={};target={}
for r,(q,z,k) in enumerate(R):
 for kind,order in [('S',q),('T',z)]:
  prev=0
  for j in range(2,order+1):
   w=theta*k*F(U)**(j-q) if kind=='S' else theta*F(U)**(-j)
   s=species(f'{kind}{r},{j}',j,w)
   if j==2:kf=K*theta*k*F(U)**(2-q) if kind=='S' else K*theta/F(U)**2
   else:kf=K*U if kind=='S' else K/U
   pair(complex_(prev,0),complex_(s),kf,K,'prefix')
   prev=s
  (source if kind=='S' else target)[r]=None if order==0 else prev
 if q:
  c=species(f'C{r}',q,theta*k);pending[r]=c
  pair(complex_(source[r]),complex_(c),K if q>=2 else K*theta*k,K,'pending')
  channel(complex_(c),{} if z==0 else complex_(target[r]),Q,'observed',r)
 else:channel({},{} if z==0 else complex_(target[r]),k,'observed',r)
for r,c in pending.items():
 for s in range(len(names)):channel(complex_(c,s),complex_(source[r],s),eta*payload[s],'collision',r)

def ff(u,a):
 ans=1
 for i,v in a.items():
  if u[i]<v:return 0
  ans*=factorial(u[i])//factorial(u[i]-v)
 return ans

def states(n,i=0):
 if i==len(payload):
  if n==0:yield ()
  return
 for k in range(n//payload[i]+1):
  for rest in states(n-k*payload[i],i+1):yield (k,)+rest

def weight(u):return prod(w**n/F(factorial(n)) for w,n in zip(weights,u))

def monomial(w,a):return prod(w[i]**n for i,n in a.items())

assert len(names)==1+sum(max(0,q-1)+max(0,z-1)+(q>0) for q,z,k in R)
assert all(1<=p<=3 for p in payload)
checks=0;fibre=[];self_exclusion_witness=False
for n in range(6):
 us=list(states(n)); Z=sum((weight(u) for u in us),F(0));qval=F(factorial(n))*Z
 fibre.append((Z,qval,us))
 for a,b,k,kind,r in channels:
  assert sum(a.values())<=2 and sum(b.values())<=2
  delta=sum(payload[i]*j for i,j in b.items())-sum(payload[i]*j for i,j in a.items())
  assert delta==(R[r][1]-R[r][0] if kind=='observed' else 0)
  if kind in ('prefix','pending'):
   reverse=[e for e in channels if e[0]==b and e[1]==a and e[3]==kind]
   assert any(k*monomial(weights,a)==e[2]*monomial(weights,b) for e in reverse)
 for u in us:
  for r,c in pending.items():
   got=sum((k*ff(u,a) for a,b,k,kind,rr in channels if kind=='collision' and rr==r),F(0))
   assert got==eta*u[c]*(n-R[r][0]);checks+=1
   if u[c]>=2:self_exclusion_witness=True
  for a,b,k,kind,r in channels:
   if kind=='observed' and ff(u,a):assert n>=R[r][0]
 for r,c in pending.items():
  q=R[r][0]
  mean=sum((u[c]*weight(u) for u in us),F(0))/Z
  expected=F(0) if n<q else theta*R[r][2]*F(factorial(n),factorial(n-q))*fibre[n-q][1]/qval
  assert mean==expected
assert self_exclusion_witness

# A separate conservative paired fixture, 2A <-> B, with activities (2,4).
a=[F(2),F(4),theta/F(U)**2*4,theta/F(U)**2*4,theta/U*4]
# species A,B,S_+,C_+,C_-
pairs=[(complex_(0,0),complex_(2),K*theta/F(U)**2,K),
       (complex_(2),complex_(3),K,K),
       (complex_(1),complex_(4),K*theta/U,K),
       (complex_(3),complex_(4),Q*U**2,Q*U)]
weights_mass=[1,2,2,2,2]
for x,y,kf,kb in pairs:
 assert kf*monomial(a,x)==kb*monomial(a,y)
 assert sum(weights_mass[i]*v for i,v in x.items())==sum(weights_mass[i]*v for i,v in y.items())

# Finite checks of the absorption-time recurrence (the paper proves it for all q).
for q in range(1,13):
 for ratio in [F(1,2),F(1),F(2),F(17)]:
  d=F(1);T=d
  for i in range(q-1):d=1+ratio*d;T+=d
  assert T==sum((q-j)*ratio**j for j in range(q))

report={'scope':'Exact finite algebra and graph fixtures only; no full compiler, infinite-state theorem or physical process was executed.',
 'open_fixture':{'species':len(names),'channels':len(channels),'decoded_populations':list(range(6)),
  'fine_states_checked':sum(len(x[2]) for x in fibre),'collision_identities':checks,
  'hidden_activity_pairs':True,'averaged_pending_identity':True,'self_exclusion_witness':True,
  'elementarity_and_decoded_changes':True,'original_null_and_parallel_marks_retained':True},
 'paired_conservative_fixture':{'reverse_pairs':len(pairs),'exact_balance':True,'conservation':True},
 'birth_death_recurrence_fixtures':48,'result':'PASS'}
Path(__file__).with_name('finite_identity_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
