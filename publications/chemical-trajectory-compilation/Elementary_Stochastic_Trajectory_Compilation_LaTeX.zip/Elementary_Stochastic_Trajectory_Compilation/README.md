# Compiling Stochastic Chemical Trajectories with Elementary Reactions

Harjas Sandhu, The University of Queensland. Manuscript dated 13 November 2026.

Build `main.tex` with the installed TeX toolchain:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The bibliography is included in references.tex. The conceptual diagram is native
TikZ source; no image or bibliography file is downloaded during compilation.
All files needed for the mathematical manuscript are included.

Theorem 2.1 is the open, drift-qualified variable-order trajectory compiler.
Theorem 9.1 is a separate conservative paired detailed-balanced construction;
Corollary 9.2 supplies its zero-upper-drift balanced subcase. The main physical
charge W includes the target activity envelope at the analytical cutoff. The
balanced charge W_b adds Xi for the supplied activities. Polynomial binary and
numerical physical costs are distinct. The construction is an ideal mass-action
model; no molecular device, practical advantage or executed complete compiler
is claimed.

The checks/ script is an exact finite-fixture identity check only. Run:

    python3 checks/check_finite_identities.py

It supports the graph/payload, collision, factorial and paired-balance identities;
it does not certify the infinite-state theorem or simulate the full operation.
The complete proofs are in the manuscript.

This package is an unpublished manuscript source release to its author for review.
No Zenodo DOI or publication is claimed. Scientific provenance and held-source
access accounting are in the separate project dossier, not in the article.
