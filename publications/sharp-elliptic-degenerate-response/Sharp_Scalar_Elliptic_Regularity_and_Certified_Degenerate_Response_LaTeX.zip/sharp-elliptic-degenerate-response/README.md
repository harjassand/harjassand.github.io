# Sharp Scalar Elliptic Regularity and Certified Degenerate Response

Harjas Sandhu, The University of Queensland. Manuscript dated 15 November 2026.

## Build

Requirements: pdfLaTeX, BibTeX and latexmk with AMS packages, Latin Modern, microtype, hyperref and TikZ. No shell escape, network access or additional software is required. The verification scripts use only Python 3.9+ standard library.

Modular build:

    cd source
    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
    PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_certificates.py
    PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_revision.py

The standalone TeX at the archive root embeds all inputs, the vector figure and bibliography. Copy it to an empty directory and build it with latexmk -pdf. The modular bibliography is source/references.bib.

To regenerate the exact data:

    cd source
    PYTHONDONTWRITEBYTECODE=1 python3 scripts/reconstruct_certificates.py
    PYTHONDONTWRITEBYTECODE=1 python3 scripts/verify_revision.py --write-record

To regenerate the standalone source after the modular build:

    python3 scripts/make_standalone.py --bbl main.bbl --output ../Sharp_Scalar_Elliptic_Regularity_and_Certified_Degenerate_Response.tex

## Scope

All PDE assertions concern scalar unknowns and real vector gradients. The maximal uniform strong elliptic interval is open. Its attained local weak upper endpoint concerns homogeneous W1,2 solutions and their flux divided by sqrt(lambda Lambda), with a homogeneous uniformly convex corollary retaining D_zW(x,0)=0. It is not a global forced or arbitrary-boundary endpoint theorem.

The logarithmic regularity theorem assumes an integrable nonnegative energy product and the stated exponential distortion moment. Its strong logarithmic endpoint and general superquadratic power gain fail by explicit examples.

Periodic response, matrix-energy density and primal-dual certification use symmetric positive-definite coefficients with a fixed-unit exponential moment for both coefficient and inverse. The represented-input rational algorithm charges coefficient acquisition and expanded spatial and arithmetic data; no uniform polynomial complexity is claimed.

Qualitative homogenization covers the two specified variational domains and L2 loading on bounded Lipschitz domains. The separate square-root-scale L2 and weighted corrector estimate requires a bounded C2 domain and an actual C2 zero-trace macroscopic solution controlled in W2,infinity. No general-data or optimal rate, stochastic theorem, unweighted L2 gradient bound or practical solver advantage is asserted. Relative-edit stability requires bounded relative comparability and the actual exponential moments for both media.

The article gives full central proofs, prior credit, limitations and its Acknowledgements and AI use section. Finite scripts supplement these proofs and do not establish universal PDE theorems by computation. Historical priority is not claimed.

## Licence

CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ . Attribution and mathematical-source credits are retained in the article and bibliography.
