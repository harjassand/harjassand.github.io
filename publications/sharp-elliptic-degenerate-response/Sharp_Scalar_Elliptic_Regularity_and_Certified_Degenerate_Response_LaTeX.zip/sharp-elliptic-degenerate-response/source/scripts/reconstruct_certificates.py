#!/usr/bin/env python3
"""New reconstruction from the manuscript formulas; Python standard library only.

Exact fractions decide every certificate test. Decimal output is display only.
This does not implement or benchmark the general degenerate finite-element search.
"""
from fractions import Fraction as F
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import json

ZERO = (F(0), F(0))
ONE = (F(1), F(0))
def cz(x): return (F(x), F(0))
def add(x, y): return (x[0]+y[0], x[1]+y[1])
def neg(x): return (-x[0], -x[1])
def sub(x, y): return add(x, neg(y))
def mul(x, y): return (x[0]*y[0]-x[1]*y[1], x[0]*y[1]+x[1]*y[0])
def scale(x, q): return (x[0]*q, x[1]*q)
def csum(xs):
    v=ZERO
    for x in xs: v=add(v,x)
    return v
def vzero(): return [ZERO,ZERO]
def mzero(): return [[ZERO,ZERO],[ZERO,ZERO]]
def clean_v(v): return {m:c for m,c in v.items() if any(x!=ZERO for x in c)}
def clean_m(v): return {m:c for m,c in v.items() if any(x!=ZERO for row in c for x in row)}
def vadd(a,b):
    return clean_v({m:[add(a.get(m,vzero())[i],b.get(m,vzero())[i])
                        for i in range(2)] for m in a.keys()|b.keys()})
def vscale(a,q): return clean_v({m:[scale(x,q) for x in c] for m,c in a.items()})
def madd(a,b):
    return clean_m({m:[[add(a.get(m,mzero())[i][j],b.get(m,mzero())[i][j])
                      for j in range(2)] for i in range(2)]
                    for m in a.keys()|b.keys()})
def mscale(a,q): return clean_m({m:[[scale(x,q) for x in row] for row in c]
                               for m,c in a.items()})
def mv(a,b):
    out={}
    for m,c in a.items():
        for n,v in b.items():
            key=(m[0]+n[0],m[1]+n[1])
            z=[csum(mul(c[i][j],v[j]) for j in range(2)) for i in range(2)]
            out[key]=[add(x,y) for x,y in zip(out.get(key,vzero()),z)]
    return clean_v(out)
def mm(a,b):
    out={}
    for m,c in a.items():
        for n,v in b.items():
            key=(m[0]+n[0],m[1]+n[1])
            z=[[csum(mul(c[i][j],v[j][k]) for j in range(2))
                for k in range(2)] for i in range(2)]
            old=out.get(key,mzero())
            out[key]=[[add(old[i][j],z[i][j]) for j in range(2)] for i in range(2)]
    return clean_m(out)
def project(v):
    out={}
    for m,c in v.items():
        den=m[0]**2+m[1]**2
        if den:
            dot=csum(scale(c[i],F(m[i])) for i in range(2))
            out[m]=[scale(dot,F(m[i],den)) for i in range(2)]
    return clean_v(out)
def reflect(v): return vadd(vscale(project(v),F(2)),vscale(v,F(-1)))
def coefficient_bound(v):
    return sum((abs(x[0])+abs(x[1]) for c in v.values() for x in c),F(0))
def enc_complex(x): return [str(x[0]),str(x[1])]
def enc_vector(v):
    return {",".join(map(str,m)):[enc_complex(x) for x in v[m]] for m in sorted(v)}
def check_real(v):
    for m,c in v.items():
        n=(-m[0],-m[1])
        assert v.get(n,vzero())==[(x[0],-x[1]) for x in c]
def decimal(x):
    with localcontext() as ctx:
        ctx.prec=35
        return str(Decimal(x.numerator)/Decimal(x.denominator))
def bits(x): return max(abs(x.numerator).bit_length(),x.denominator.bit_length())

def fourier():
    k=F(3,10); cp=F(3); rho=k*cp; eps=F(1,256)
    identity={(0,0):[[ONE,ZERO],[ZERO,ONE]]}
    M={}
    for sign in [-1,1]:
        co=cz(k/2); si=(F(0),-sign*k/2)
        M[(sign,0)]=[[co,si],[si,neg(co)]]
    h={(0,1):[cz(F(1,2)),ZERO],(0,-1):[cz(F(1,2)),ZERO],
       (1,1):[ZERO,(F(0),F(-1,2))],(-1,-1):[ZERO,(F(0),F(1,2))]}
    assert mm(M,M)==mscale(identity,k*k)
    A=mscale(madd(mscale(identity,1+k*k),mscale(M,-2)),1/(1-k*k))
    forcing=vscale(mv(madd(identity,mscale(M,-1)),h),1/(1-k*k))
    assert mm(A,madd(identity,M))==madd(identity,mscale(M,-1))
    assert mv(madd(identity,A),h)==vscale(forcing,F(2))
    # Zero frequency convention is deliberately exercised.
    assert reflect({(0,0):[ONE,ZERO]})=={(0,0):[neg(ONE),ZERO]}
    f={}
    for _ in range(10): f=reflect(vadd(mv(M,f),h))
    E=project(f); B=vadd(f,vscale(E,-1))
    residual=vadd(vadd(reflect(f),vscale(mv(M,f),-1)),vscale(h,-1))
    for m,c in E.items():
        assert sub(scale(c[1],F(m[0])),scale(c[0],F(m[1])))==ZERO
    for m,c in B.items():
        assert csum(scale(c[i],F(m[i])) for i in range(2))==ZERO
    constitutive_gap=vadd(vadd(mv(A,E),vscale(B,-1)),vscale(forcing,-1))
    assert constitutive_gap==vscale(mv(madd(identity,A),residual),F(1,2))
    for field in [h,f,E,B,residual]: check_real(field)
    factor=(1+cp)*cp/(2*(1-rho))
    err=factor*coefficient_bound(residual)
    assert err<eps
    prior=0
    while factor*rho**prior*coefficient_bound(h)>eps: prior+=1
    assert prior==99
    # k=0 has rho=0 and one exact Picard step.
    assert reflect(reflect(h))==h
    return {
       "origin":"new exact reconstruction from displayed formulas",
       "p":4,"k":str(k),"contraction_factor":str(rho),"iterations":10,
       "gradient_modes":len(E),"residual_modes":len(residual),
       "residual_coefficient_l1_bound":str(coefficient_bound(residual)),
       "gradient_error_bound":str(err),"gradient_error_decimal":decimal(err),
       "requested_error":str(eps),"a_priori_iteration_cap":prior,
       "certificate_factor":str(factor),
       "M_squared_identity_verified":True,"cayley_identities_verified":True,
       "curl_gradient_and_div_flux_verified":True,
       "finite_constitutive_gap_identity_verified":True,
       "f":enc_vector(f),"E":enc_vector(E),"B":enc_vector(B),
       "residual":enc_vector(residual),
       "maximum_field_fraction_bits":max(bits(x) for field in [f,E,B,residual]
                      for c in field.values() for z in c for x in z)}

def parity_tail(J,odd):
    j=J+1
    if bool(j%2)!=odd: j+=1
    w=F(4,3)*F(1,2**j)
    integer=F(1,2**j)*(F(4*j,3)+F(8,9))
    return w,integer
def laminate(J=50):
    t=F(1,2**J)
    ap=sum((F(1,2**j)*(F(j) if j%2 else F(1,j))
            for j in range(1,J+1)),F(0))
    bp=sum((F(1,2**j)*(F(1,j) if j%2 else F(j))
            for j in range(1,J+1)),F(0))
    h=1/(bp+t)
    wo,ot=parity_tail(J,True); we,et=parity_tail(J,False)
    assert wo+we==t and ot+et==(J+2)*t
    ua=ot+we/(J+1); ub=et+wo/(J+1)
    T=(F(J)+F(1,J+1))*t
    L1=h-h*h*(ub-t); U1=h+h*h*(ua-t)
    L2=ap+2*t-ub; U2=ap+ua
    assert U1-L1==h*h*T and U2-L2==T
    assert U1-L1<F(2148,10**17) and U2-L2<F(4443,10**17)
    tensor_squared=8*((U1-L1)+(U2-L2))
    assert tensor_squared<F(1,10**12)
    payload={"J":J,"tau":"1/4","M":"2","mu":"8","tail_volume":str(t),
      "finite_mean_a":str(ap+t),"finite_mean_inverse_a":str(bp+t),
      "h_J":str(h),"tail_integer_odd":str(ot),"tail_integer_even":str(et),
      "upper_tail_a":str(ua),"upper_tail_inverse_a":str(ub),
      "tail_gap_bound":str(T),
      "L1":str(L1),"U1":str(U1),"L2":str(L2),"U2":str(U2),
      "width1":str(U1-L1),"width2":str(U2-L2),
      "width1_decimal":decimal(U1-L1),"width2_decimal":decimal(U2-L2),
      "operator_error_squared_bound":str(tensor_squared),
      "operator_error_less_than":"1/1000000",
      "pointwise_and_mean_compatibility":"proved in manuscript",
      "origin":"new finite rational trials and infinite-series tail certificate"}
    nums=[F(v) for key,v in payload.items() if isinstance(v,str) and
          key not in ("origin","pointwise_and_mean_compatibility",
          "width1_decimal","width2_decimal")]
    payload["maximum_certificate_fraction_bits"]=max(map(bits,nums))
    return payload

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output-dir",type=Path,
        default=Path(__file__).resolve().parents[1]/"data")
    args=parser.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    a=fourier();b=laminate()
    (args.output_dir/"fourier_certificate.json").write_text(json.dumps(a,indent=2)+"\n")
    (args.output_dir/"laminate_certificate.json").write_text(json.dumps(b,indent=2)+"\n")
    print(json.dumps({"fourier_error":a["gradient_error_bound"],
      "fourier_modes":a["gradient_modes"],"prior_cap":a["a_priori_iteration_cap"],
      "laminate_widths":[b["width1_decimal"],b["width2_decimal"]],
      "laminate_max_bits":b["maximum_certificate_fraction_bits"]},indent=2))

if __name__=="__main__": main()
