#!/usr/bin/env python3
"""Replay the finite reconstructions, and check a noncommuting filter example.

No floating-point arithmetic is used for a success decision.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import reconstruct_certificates as rc

def plus(A,B): return [[A[i][j]+B[i][j] for j in range(2)] for i in range(2)]
def times(A,B): return [[sum(A[i][k]*B[k][j] for k in range(2))
                        for j in range(2)] for i in range(2)]
def scale(A,c): return [[c*x for x in row] for row in A]
def inv(A):
    det=A[0][0]*A[1][1]-A[0][1]*A[1][0]
    assert det
    return [[A[1][1]/det,-A[0][1]/det],[-A[1][0]/det,A[0][0]/det]]
I=[[F(1),F(0)],[F(0),F(1)]]
Z=scale(I,0)
def inverse_filter(A,R,k):
    T=inv(plus(I,scale(times(A,A),R*R)))
    power=I; total=Z
    for _ in range(k):
        power=times(power,T);total=plus(total,power)
    C=scale(times(A,total),R*R)
    return C,T,power

root=Path(__file__).resolve().parents[1]
for name,actual in [("fourier_certificate.json",rc.fourier()),
                    ("laminate_certificate.json",rc.laminate())]:
    expected=json.loads((root/"data"/name).read_text())
    assert actual==expected, name

X=[[F(1),F(0)],[F(0),F(2)]]
Y=[[F(1),F(1,10)],[F(1,10),F(2)]]
assert times(X,Y)!=times(Y,X)
R=F(2);k=3
CX,TX,TXk=inverse_filter(X,R,k)
CY,_,_=inverse_filter(Y,R,k)
assert plus(inv(X),scale(CX,-1))==times(inv(X),TXk)
diff=plus(CX,scale(CY,-1))
frob2=sum(x*x for row in diff for x in row)
# ||X-Y||op=1/10; ||C(X)-C(Y)||op^2 <= Frobenius^2.
bound2=(F(k*(k+3),4)*R*R)**2/F(100)
assert frob2<=bound2
negative=[[-F(1),F(1,3)],[F(1,3),F(2)]]
G=plus(I,scale(times(negative,negative),R*R))
assert G[0][0]>0 and G[0][0]*G[1][1]-G[0][1]**2>0
for beta,tau in [(F(1,10),F(1,5)),(F(1),F(3,2)),(F(2999,1000),F(3))]:
    gamma=(beta+tau)/2;eta=(gamma-beta)/(8*gamma)
    margin=(1-eta)/beta-(1+eta)**2/gamma
    assert margin>=(gamma-beta)/(2*beta*gamma)>0
report={
 "finite_fourier_reconstruction":"passed",
 "infinite_laminate_rational_tail_certificate":"passed",
 "noncommuting_resolvent_filter_example":"passed",
 "indefinite_approximate_matrix_filter":"passed",
 "near_threshold_rational_absorption_checks":"passed",
 "general_theorems":"proved in manuscript, not inferred from these checks",
 "independent_reviewers":"none commissioned or claimed"}
print(json.dumps(report,indent=2))
