#!/usr/bin/env python3
"""Flatten local TeX inputs and embed the generated bibliography."""
from pathlib import Path
import argparse
import re

parser=argparse.ArgumentParser()
parser.add_argument("--bbl",type=Path,required=True)
parser.add_argument("--output",type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
def flatten(path,stack=()):
    path=path.resolve()
    if path in stack: raise ValueError("cyclic TeX input")
    if not path.is_relative_to(root): raise ValueError("nonlocal input")
    text=path.read_text()
    def insert(match):
        child=root/(match.group(1)+".tex")
        return "\n% Begin embedded "+match.group(1)+"\n"+flatten(child,stack+(path,))+"\n% End embedded input\n"
    return re.sub(r"\\input\{([^}]+)\}",insert,text)

text=flatten(root/"main.tex")
text=re.sub(r"\\bibliographystyle\{[^}]+\}","",text)
text=text.replace(r"\bibliography{references}",args.bbl.read_text())
assert not re.search(r"\\(?:input|include|bibliography)\{",text)
args.output.write_text("% Standalone source: bibliography and vector figure are embedded.\n"+text)
print(args.output)
