#!/usr/bin/env python3
"""Exact finite consistency checks supplementing the written revision proofs.

These are not numerical evidence for a universal PDE theorem.
Only Python's standard library is required.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import json


def add(A, B):
    return [[x + y for x, y in zip(a, b)] for a, b in zip(A, B)]


def scale(A, c):
    return [[c * x for x in row] for row in A]


def mul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(2))
             for j in range(2)] for i in range(2)]


def inv(A):
    determinant = A[0][0] * A[1][1] - A[0][1] * A[1][0]
    assert determinant
    return [[A[1][1] / determinant, -A[0][1] / determinant],
            [-A[1][0] / determinant, A[0][0] / determinant]]


def psd(A):
    assert A[0][1] == A[1][0]
    return (A[0][0] >= 0 and A[1][1] >= 0
            and A[0][0] * A[1][1] - A[0][1] ** 2 >= 0)


def checks():
    count = 0
    for d in range(2, 25):
        for s in (F(1001, 1000), F(101, 100), F(11, 10),
                  F(3, 2), F(2), F(3), F(11), F(101), F(10001)):
            P = 2 * s / (s - 1)
            a = P + P * P / (2 * (d + P))
            lower = max(F(2), d * a / (d + a),
                        a * (P - 1) / (a - 1),
                        a * (P - 2) / (a - 2))
            p = (P + lower) / 2
            assert 2 < p < P < a
            assert p > d * a / (d + a)
            theta1 = p * (1 - 1 / a) - 1
            theta2 = p * (1 - 2 / a)
            assert min(theta1, theta2) > P - 2 > 0
            # Single-atom check of the exact calibration-to-ODE algebra.
            for t, r in ((F(1), F(5, 4)), (F(2), F(7))):
                f = (r - t) ** 2
                fp = -2 * (r - t)
                assert (r - t) * (r / s - t) == (
                    f + (s - 1) * t * fp / 2) / s
            count += 1

    for d in range(2, 101):
        q = F(2 * d + 1, d + 1)
        m = 2 * d + 1
        b = F(2 * m, m - 1)
        qstar = d * q / (d - q)
        assert m == q / (2 - q)
        assert b == 2 + F(1, d)
        assert qstar / b == F(d * d, d * d - d - 1) > 1
        assert q > F(2 * d, d + 2)

    A = [[F(3), F(1)], [F(1), F(2)]]
    T = [[F(4), F(0)], [F(0), F(1)]]
    gamma = F(4)
    assert mul(A, T) != mul(T, A)
    assert psd(add(T, scale(A, -1 / gamma)))
    assert psd(add(scale(A, gamma), scale(T, -1)))
    difference = add(T, scale(A, -1))
    left = mul(mul(difference, inv(T)), difference)
    right = add(add(T, scale(A, -2)), mul(mul(A, inv(T)), A))
    assert left == right
    relative_bound = add(scale(A, gamma + 1 / gamma - 2),
                         scale(left, -1))
    assert psd(relative_bound)
    return {
        "endpoint_rational_parameter_cases": count,
        "dimensions_checked_for_endpoint": [2, 24],
        "endpoint_s_values": ["1001/1000", "101/100", "11/10", "3/2",
                              "2", "3", "11", "101", "10001"],
        "strict_cutoff_tail_margins": "passed in every recorded finite case",
        "tail_ODE_algebra_cases": 2 * count,
        "weighted_exponent_dimensions": [2, 100],
        "weighted_Sobolev_and_compactness_inequalities": "passed",
        "relative_edit_noncommuting_identity": "passed",
        "relative_edit_rational_PSD_bound": "passed",
        "relative_edit_quadratic_form": [[str(x) for x in row]
                                        for row in left],
        "status": "exact finite checks; universal arguments are in the article"
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--write-record", action="store_true")
    args = parser.parse_args()
    report = checks()
    record = Path(__file__).resolve().parents[1] / "data/revision_exact_checks.json"
    if args.write_record:
        record.write_text(json.dumps(report, indent=2) + "\n")
    else:
        assert report == json.loads(record.read_text())
    print(json.dumps(report, indent=2))
