"""Exact rational/symbolic derivation of the radial integration identity.

No quadrature: spherical conditional moments reduce the rational trace to
three elementary scalar integrals U1,U2,U3.
"""
import sympy as s

q,Y,Z,z,t=s.symbols('q Y Z z t')
U1,U2,U3=s.symbols('U1 U2 U3')
root=s.sqrt(2)
a=q+1
y0=(Y-a)/2;z0=(Z-a)/2
x2=q-y0*y0-z0*z0
H=q*q+2*q*(y0+z0)+3*q-2*y0*y0+2*y0*z0+2*z0
E=-4*x2*(Y-q)*(Z-q)*H/(q*Y*Z*(Y+Z-q))
E=s.factor((E+E.xreplace({Y:Z,Z:Y}))/2)

def sphere_1d(poly,var):
    ans=0
    for (n,),c in s.Poly(s.expand(poly),var).terms():
        if n%2==0:ans+=c*q**(n//2)/s.Integer(n+1)
    return s.expand(ans)

def circle_moment(m):return s.binomial(2*m,m)/4**m

def over_Z(n):
    poly=sum(s.binomial(n,2*m)*a**(n-2*m)*2**(2*m)*circle_moment(m)*(q-z*z)**m for m in range(n//2+1))
    quot,rem=s.div(s.expand(poly),a+2*z,z)
    return s.expand(sphere_1d(quot,z)+rem*U1)

def over_S(n):
    poly=sum(s.binomial(n,2*m)*(a+root*t)**(n-2*m)*2**m*circle_moment(m)*(q-t*t)**m for m in range(n//2+1))
    quot,rem=s.div(s.expand(poly),q+2+2*root*t,t)
    return s.expand(sphere_1d(quot,t)+rem*U3)

def moment(n,m):
    if n%2 or m%2:return 0
    return q**((n+m)//2)*s.factorial2(n-1)*s.factorial2(m-1)/s.factorial2(n+m+1)

def polynomial_YZ(n,m):
    yy,zz=s.symbols('yy zz')
    poly=s.Poly(s.expand((a+2*yy)**n*(a+2*zz)**m),yy,zz)
    return s.expand(sum(c*moment(*p) for p,c in poly.terms()))

resY=s.cancel(s.cancel(Y*E).subs(Y,0))
resS=s.cancel(s.cancel((Y+Z-q)*E).subs(Y,q-Z))
pol=s.cancel(E-resY/Y-resS/(Y+Z-q))
answer=0
# Laurent polynomial in Y,Z: multiply by Z and remove the extra power.
for (n,m),c in s.Poly(s.cancel(pol*Z),Y,Z).terms():
    m-=1
    answer+=c*(over_Z(n) if m==-1 else polynomial_YZ(n,m))
for (m,),c in s.Poly(s.cancel(resY*Z),Z).terms():
    m-=1
    answer+=c*(U2 if m==-1 else over_Z(m))
for (m,),c in s.Poly(resS,Z).terms():
    answer+=c*over_S(m)
answer=s.factor(answer)
expected=47*q*q/64+31*q/96-s.Rational(3,16)+3/(8*q)
expected-=(11*q**3+3*q*q+9*q+9)*U1/4
expected+=2*(q*q+1)**2*U2
expected+=(q-2)**3*(q+6)*U3/(64*q)
assert s.cancel(answer-expected)==0
print('Exact radial integration identity verified.')
print(s.collect(s.expand(answer),(U1,U2,U3)))

# Check both tail expansions directly from the three elementary averages.
# U2 is the integral of 1/(1-8q*w^2+q^2) on [-1/2,1/2].
w=s.symbols('w')
c=[s.Integer(1),8*w*w]
for n in range(2,10):c.append(s.expand(8*w*w*c[-1]-c[-2]))
cavg=[s.integrate(p,(w,-s.Rational(1,2),s.Rational(1,2))) for p in c]
u1=sum(q**n/s.Integer(2*n+1) for n in range(10))
u2=sum(cavg[n]*q**n for n in range(10))
u3=sum(q**n/(2**(n+1)*s.Integer(2*n+1)) for n in range(10))
low=s.expand(s.Rational(3,4)*expected.subs({U1:u1,U2:u2,U3:u3}))
u1h=q*u1
u2h=q*q*u2
u3h=q*sum(2**n*q**n/s.Integer(2*n+1) for n in range(10))
high=s.expand(s.Rational(3,4)*expected.subs(q,1/q).subs({U1:u1h,U2:u2h,U3:u3h}))
low_expected=[-s.Rational(11,10),s.Rational(249,140),-s.Rational(311,280),s.Rational(881,3696),s.Rational(16231,160160)]
high_expected=[-s.Rational(3,35),-s.Rational(1,105),s.Rational(17,385),-s.Rational(89,1001),-s.Rational(131,2145),-s.Rational(3,935)]
assert [low.coeff(q,n) for n in range(1,6)]==low_expected
assert [high.coeff(q,n) for n in range(1,7)]==high_expected
assert [low.coeff(q,n) for n in (-1,0)]==[0,0]
assert [high.coeff(q,n) for n in (-2,-1,0)]==[0,0,0]
print('Exact low and high tail coefficients verified.')
