"""Exact radial sign certificate for the common-control construction.

Dyadic outward-rounded integer interval arithmetic and second-order Taylor
bounds verify all 4096 middle intervals. Python 3 standard library only.
Run: python3 code/verify_radial_sign.py
"""
from math import isqrt
from functools import lru_cache
import json

BITS=180
SCALE=1<<BITS

def ceildiv(a,b):
    return -((-a)//b)

class I:
    __slots__=('lo','hi')
    def __init__(self,lo,hi=None,raw=False):
        if raw:
            self.lo=lo; self.hi=lo if hi is None else hi
        else:
            self.lo=lo*SCALE; self.hi=(lo if hi is None else hi)*SCALE
        assert self.lo<=self.hi
    @classmethod
    def rational(cls,a,b=1):
        assert b>0
        return cls(a*SCALE//b,ceildiv(a*SCALE,b),raw=True)
    def __add__(a,b):
        b=iv(b); return I(a.lo+b.lo,a.hi+b.hi,raw=True)
    __radd__=__add__
    def __neg__(a):
        return I(-a.hi,-a.lo,raw=True)
    def __sub__(a,b): return a+-iv(b)
    def __rsub__(a,b): return iv(b)+-a
    def __mul__(a,b):
        b=iv(b)
        v=(a.lo*b.lo,a.lo*b.hi,a.hi*b.lo,a.hi*b.hi)
        return I(min(v)//SCALE,ceildiv(max(v),SCALE),raw=True)
    __rmul__=__mul__
    def inv(a):
        assert not a.lo<=0<=a.hi, ('zero reciprocal',a.lo,a.hi)
        return I(SCALE*SCALE//a.hi,ceildiv(SCALE*SCALE,a.lo),raw=True)
    def __truediv__(a,b): return a*iv(b).inv()
    def __rtruediv__(a,b): return iv(b)*a.inv()
    def __pow__(a,n):
        assert n>=0
        if n==0:return I(1)
        if n==1:return a
        b=a**(n//2); out=b*b
        return out*a if n%2 else out
    def sqrt(a):
        assert a.lo>=0
        lo=isqrt(a.lo*SCALE); hi=isqrt(a.hi*SCALE)
        return I(lo,hi+(hi*hi<a.hi*SCALE),raw=True)
    def log(a):
        assert a.lo>0
        lo=log_point(a.lo); hi=log_point(a.hi)
        return I(lo.lo,hi.hi,raw=True)
    def absmax(a):return max(abs(a.lo),abs(a.hi))

def iv(x):return x if isinstance(x,I) else I(x)

def atanh_log(x):
    y=(x-1)/(x+1); y2=y*y; power=y; out=I(0)
    for j in range(80):
        out=out+power/I(2*j+1)
        power=power*y2
    rem=(2*power/(161*(1-y2))).absmax()
    out=2*out
    return I(out.lo-rem,out.hi+rem,raw=True)

LOG2=atanh_log(I(2))

@lru_cache(maxsize=300000)
def log_point(n):
    assert n>0
    e=n.bit_length()-SCALE.bit_length()
    if e>=0:
        d=1<<e
        x=I(n//d,ceildiv(n,d),raw=True)
    else:
        x=I(n<<(-e),raw=True)
    assert x.lo>=SCALE and x.hi<=2*SCALE+1
    return atanh_log(x)+e*LOG2

class J:
    __slots__=('c',)
    def __init__(self,a,b=0,c=0):self.c=(iv(a),iv(b),iv(c))
    def __add__(a,b):
        b=jet(b); return J(*(x+y for x,y in zip(a.c,b.c)))
    __radd__=__add__
    def __neg__(a):return J(*(-x for x in a.c))
    def __sub__(a,b):return a+-jet(b)
    def __rsub__(a,b):return jet(b)+-a
    def __mul__(a,b):
        b=jet(b)
        return J(*(sum((a.c[j]*b.c[n-j] for j in range(n+1)),I(0)) for n in range(3)))
    __rmul__=__mul__
    def inv(a):
        b0=1/a.c[0]
        return J(b0,-a.c[1]*b0**2,a.c[1]**2*b0**3-a.c[2]*b0**2)
    def __truediv__(a,b):return a*jet(b).inv()
    def __rtruediv__(a,b):return jet(b)*a.inv()
    def __pow__(a,n):
        assert n>=0
        if n==0:return J(1)
        if n==1:return a
        b=a**(n//2);out=b*b
        return out*a if n%2 else out
    def sqrt(a):
        b0=a.c[0].sqrt();b1=a.c[1]/(2*b0)
        b2=(a.c[2]-b1*b1)/(2*b0)
        return J(b0,b1,b2)
    def log(a):
        b1=a.c[1]/a.c[0]
        return J(a.c[0].log(),b1,a.c[2]/a.c[0]-b1*b1/2)

def jet(x):return x if isinstance(x,J) else J(x)

SQRT2=I(2).sqrt()

def glog(z):
    assert z.c[1].lo==SCALE==z.c[1].hi and z.c[2].lo==z.c[2].hi==0
    x=z.c[0]
    if x.lo<=0<=x.hi:
        m=x.absmax()
        if not m:return J(0)
        assert m*16<SCALE
        a=I(m,raw=True); minuslog=-a.log()
        b0=(a**3*minuslog).hi
        b1=(a*a*(3*minuslog+1)).hi
        b2=(a*(6*minuslog+5)/2).hi
        return J(I(-b0,b0,raw=True),I(-b1,0,raw=True),I(-b2,b2,raw=True))
    absx=x if x.lo>0 else -x
    l=absx.log()
    return J(x**3*l,x*x*(3*l+1),x*(6*l+5)/2)

def radial_jet(x):
    r=J(x,1);q=r*r;root=(q*q+1).sqrt()
    A=(11*q**3+3*q*q+9*q+9)/(2*SQRT2)
    B=4*root**3
    polynomial=47*q*q/32+31*q/48-J(I.rational(3,8))+3/(4*q)
    p=7*q**3-45*q*q+21*q-47
    C=(q-2)**3*(q+6)/(64*q)
    C1=-(r+1)**3*p/(8*(A+B))
    C3=(r+SQRT2)**3*(q+6)/(64*q)
    regular=r*SQRT2*polynomial-(A+B)*(r+1).log()
    regular=regular+B*(root+r*SQRT2).log()+C*(r+SQRT2).log()
    val=regular+C1*glog(r-1)-C3*glog(r-SQRT2)
    return 3*val/(r*(8*SQRT2))

def verify(count=4096):
    worst=None;failed=[]
    for j in range(count):
        left=4096+63*j;right=left+63
        box=I(I.rational(left,32768).lo,I.rational(right,32768).hi,raw=True)
        mid=I.rational(left+right,65536)
        h=I.rational(63,65536)
        p=radial_jet(mid);d=radial_jet(box)
        upper=(p.c[0]+I(p.c[1].absmax(),raw=True)*h+I(d.c[2].absmax(),raw=True)*h*h).hi
        if worst is None or upper>worst[0]:worst=(upper,j)
        if upper>-(1<<(BITS-20)):failed.append((j,upper))
    result={'verified':not failed,'count':count,'scale_bits':BITS,
            'worst_upper_numerator':str(worst[0]),'worst_interval':worst[1],
            'fail_count':len(failed),'first_failures':[(j,str(v)) for j,v in failed[:20]]}
    print(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    result=verify()
    raise SystemExit(0 if result['verified'] else 1)
