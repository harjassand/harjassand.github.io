# Entropy Budgets and Weighted Concentration in Parallel Games

Harjas Sandhu, The University of Queensland. 6 November 2026.

Build the modular manuscript with a current TeX Live distribution:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The bibliography is included in `references.tex`; no BibTeX database or network
download is required. Both diagrams are native TikZ and need no external image
files. The manuscript uses standard AMS, Latin Modern, microtype, geometry,
TikZ, booktabs, enumitem, needspace, hyperref and cleveref packages.

The separate standalone TeX deliverable contains the same complete text,
bibliography and diagrams in one file.

The main probability theorem is proved under its explicit conditional entropy
budget. The commuting-game corollary additionally assumes Hypothesis FR(K).
The manuscript does not assert a proof of that reconstruction hypothesis or a
general quadratic repetition theorem for arbitrary commuting games.

The acknowledgements and AI-use disclosure appear near the end of the main
text, before the appendices.
